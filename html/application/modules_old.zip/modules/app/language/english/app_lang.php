<?php
$lang['app_home']="Home";
$lang['app_whoim']=" About Us  ";
$lang['app_contactus']="  Contact Us ";
$lang['app_map']=" Site Map ";
$lang['app_theway']=" Help Center    ";
$lang['app_service']="Services";
$lang['app_jop']=" Job";
$lang['app_advert']=" News  : ";
$lang['app_articles']="News & Articles";
$lang['app_video']=" Video ";
$lang['app_newmemeber']="  New member ";
$lang['app_login']=" Login";
$lang['app_poll']=" Poll ";
$lang['app_slink']=" Contact Us";
$lang['app_maillist']=" Mailing List";
$lang['app_pagefacebook']="  facebook Page";
$lang['app_tags']=" Tags  ";
$lang['app_statices']=" Site Statistics:";

$lang['app_whoonline']=" Who's Online";
$lang['app_counter']="Visitors Counter";
$lang['app_ads']=" Advertisement ";
$lang['app_advwithus']=" Advertise with us ";


$lang['app_link_polices']="Policy";
$lang['app_link_economic']="Economy";
$lang['app_link_sport']="Sport";
$lang['app_link_tecnlogy']="Technology";
 
?>