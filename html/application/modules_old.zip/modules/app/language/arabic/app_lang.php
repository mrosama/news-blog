<?php
$lang['app_home']="الرئيسية";
$lang['app_whoim']="من نحن";
$lang['app_contactus']="اتصل بنا";
$lang['app_map']="خريطة الموقع";
$lang['app_theway']=" مركز التعليمات    ";
$lang['app_service']="خدماتنا";
$lang['app_jop']="وظائف";
$lang['app_advert']="إعلانات إدارية:";
$lang['app_articles']="ألاخبار والمقالات";
$lang['app_video']="قائمة الفيديو";
$lang['app_newmemeber']="عضوية جديدة";
$lang['app_login']="تسجيل الدخول";
$lang['app_poll']="إستطلاع الرأي";
$lang['app_slink']="   تواصل معنا";
$lang['app_maillist']=" القائمة البريدية";
$lang['app_pagefacebook']="صفحة الموقع على الفايسبوك";
$lang['app_tags']="ألاوسمة";
$lang['app_statices']="إحصائيات الموقع :";

$lang['app_whoonline']="  المتواجدون ألان";
$lang['app_counter']="عداد الزوار";
$lang['app_ads']="إعلانات إدارية";
$lang['app_advwithus']="اعلن معنا";


$lang['app_link_polices']="سياسة";
$lang['app_link_economic']="إقتصاد";
$lang['app_link_sport']="رياضة";
$lang['app_link_tecnlogy']="تكنولوجيا";
 
?>