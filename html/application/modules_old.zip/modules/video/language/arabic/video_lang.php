<?php
$lang['video_add'] ="فيديو جديد";
$lang['video_edit'] ="تعديل";
$lang['video_comments'] ="التعليقات";
$lang['video_save'] ="حفظ";
$lang['video_msgadd'] ="تم حفظ البيانات بنجاح";
$lang['video_msgerror'] ="";
$lang['video_ID'] ="مسلسل";
$lang['video_title'] ="الفيدوهات";
$lang['video_delete'] ="حذف";
$lang['video_cat'] ="القسم";
$lang['video_search'] ="بحث في اليوتيوب";
$lang['video_btn_search'] ="  بحث ";
$lang['video_btn_add'] ="تاريخ ألاضافة";
$lang['video_serach_title'] ="   بحث في اليوتيوب";
$lang['video_date'] ="تاريخ ألاضافة";
$lang['video_search_msg'] ="   نأسف لعدم وجود نتائج";
$lang['video_movetovideo']="   نقل إلي الفيدوهات";
$lang['video_error1']="من فضلك أختار من قائمة الفيديوهات";
$lang['video_error2']="من فضلك أختار القسم";
$lang['video_name']="عنوان الفيديو";
$lang['video_name_en']="عنوان الفيديو- اللغة الثانية ";
$lang['video_filename']=" تحميل ملف الفيديو";
$lang['video_pic']=" تحميل صورة";
$lang['video_youtube']="رابط YouTube";
$lang['video_youtube_msg']="سوف يتم إدراج عنوان وصورة ملف اليوتيوب تلقائي ";
$lang['video_author']="الكاتب";
$lang['video_content']="المحتوي";
$lang['video_content_en']="المحتوي - اللغة الثانية";
$lang['video_validate_title']="عنوان الفيديو مفقود";
$lang['video_validate_pic']="نوع الصورة غير مسموح بة";
$lang['video_validate_authur']="اسم الكاتب مفقود";
$lang['video_validate_file1']="اختار ملف الفيديو او ادخل رابط ملف اليوتيوب";
$lang['video_validate_youtubepic']="لا يمكنك اختيار صورة ..سوف يتم إدارج الصورة تلقائيا من اليوتيوب";
$lang['video_validate_cat']="القسم مفقود";
$lang['video_tip']="سوف يتم إدراج عنوان وصورة ملف اليوتيوب تلقائي ";
$lang['video_comment_name']="ألاسم";
$lang['video_comment_email']="البريد الالكتروني";
$lang['video_comment_status']="الحالة";
$lang['video_comment_enable']="مفعل";
$lang['video_comment_disabled']="غير مفعل";
$lang['video_comment_content']="المحتوي";
$lang['video_comment_active']="تفعيل";
$lang['video_comment_deactive']="إلغاء التفعيل";



?>