<meta charset="utf-8" />

<?php
echo modules::run('post/slidepost');
echo modules::run('post/last_post');
?>