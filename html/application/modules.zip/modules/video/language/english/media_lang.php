<?php
$lang['media_norow'] =" Sorry, there are no medias registered";
$lang['media_comments'] ="  Comments ";
$lang['media_misname']="First Name is missing";
$lang['media_misemail']="E-mail is missing or incorrectly  ";
$lang['media_send']="Send ";
$lang['media_name']="Name";
$lang['media_email']="E-mail";
$lang['media_msg']="Comment";
$lang['media_errorcode']=" Captcha is incorrect " ;
$lang['media_addcomments']=" Added comment will be published after a review of the administration";
$lang['media_comment_link']=" Added comment on medias";
$lang['media_comnum']=" reply";
$lang['media_show'] =" View ";
$lang['media_time'] ="View";
$lang['media_code'] =" Captcha";
?>