<meta charset="utf-8" />
<link rel="stylesheet" href="<?php echo base_url()?>assets/lib/flag/flags.css?v=0.1" type="text/css">



<div class="hitCounter">
<?php

echo @$hitcounter;


 
 ?>
 </div>
 

 