<?php 
$this -> load -> helper('html');
$this -> load -> helper('url');
$base= base_url("html/application/modules/app/views/Template/blooogi/");
$api=$this->load->library('apiservices');
$meta= $api->get_meta('ds5&f46#d5s@f4@#0od$0w3fdgdf');
$fp= $api->get_fb('ds5&f46#d5s@f4@#0od$0w3fdgdf');
$api->turnOff('ds5&f46#d5s@f4@#0od$0w3fdgdf');
?>
<!DOCTYPE html>
<html>

<head>
	
	<title>  <?php echo @$meta['title'];?>  </title>
	
         
    
	<meta charset="utf-8" />
	<meta name="keywords" content="<?php echo $meta['keywords'];?>" />
	<meta name="description" content="<?php echo $meta['description'];?>"  />
	<meta name="author" content="<?php echo $meta['author'];?>"  />
	<meta name="copyright" content="<?php echo $meta['copyright'];?>"  />
	
	<link rel="stylesheet" href="<?php echo $base?>/css/style.css" />
	<link rel="stylesheet" href="<?php echo $base?>/css/ticker-style.css" />
 
	
	<script src="<?php echo $base?>/javascript/jquery.min.js"></script>
	<script src="<?php echo $base?>/javascript/jquery.ticker.js"></script>
	 
	<link rel="stylesheet/less" type="text/css" href="<?php echo $base?>/css/style.less" />
	   <script src="<?php echo $base?>/javascript/less-1.6.3.min.js"></script>
 
	
	<script>
		$(function () {
			$('#js-news').ticker({
				direction: 'rtl',
				titleText: '',
				debugMode: false,
				controls: false
			});
			
		/*	$(window).load(function() {
				$('#slider').nivoSlider();
			});
			*/
		});
	</script>
	
</head>

<body>

<div id="puertoPage">

	<!-- هيدر الموقع -->
	
	<div id="puertoHeader">
		<div style="height:3px;background:#F88C00;"></div>
		
		<div class="puertoHeaderTop">
			<ul>
				<li class="date">
                 <script language="JavaScript">var fixd;function isGregLeapYear(year){return year%4 == 0 && year%100 != 0 || year%400 == 0;}function gregToFixed(year, month, day){var a = Math.floor((year - 1) / 4);var b = Math.floor((year - 1) / 100);var c = Math.floor((year - 1) / 400);var d = Math.floor((367 * month - 362) / 12);if (month <= 12)e = -2;else if (month > 2 && isGregLeapYear(year))e = 1;elsee = -1;return 1 - 1 + 365 * (year - 1) + a - b + c + d + e + day;}function Hijri(year, month, day){this.year = year;this.month = month;this.day = day;this.toFixed = hijriToFixed;this.toString = hijriToString;}function hijriToFixed(){return this.day + Math.ceil(29.5 * (this.month - 1)) + (this.year - 1) * 354 +Math.floor((3 + 11 * this.year) / 30) + 227015 - 1;}function hijriToString(){var months = new Array("محرم","صفر","ربيع أول","ربيع ثانى","جمادى الأولى","جمادى  الثانية","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة");return this.day + " " + months[this.month - 1]+ " " + this.year;}function fixedToHijri(f){var i=new Hijri(1100, 1, 1);i.year = Math.floor((30 * (f - 227015) + 10646) / 10631);var i2=new Hijri(i.year, 1, 1);var m = Math.ceil((f - 29 - i2.toFixed()) / 29.5) +1;i.month = Math.min(m, 12);i2.year = i.year;i2.month = i.month;i2.day = 1;i.day = f - i2.toFixed() + 1;return i;}var tod=new Date();var weekday=new Array("الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت");var monthname=new Array("يناير","فبراير","مارس","إبريل","مايو","يونيو","يوليوز","غشت","شتنبر","أكتوبر","نونبر","دجنبر");var y = tod.getFullYear();var m = tod.getMonth();var d = tod.getDate();var dow = tod.getDay();document.write(weekday[dow] + " " + d + " " + monthname[m] + " " + y);m++;fixd=gregToFixed(y, m, d);var h=new Hijri(1421, 11, 28);h = fixedToHijri(fixd);document.write(" م  - " + h.toString() + "هـ");</script>

             </li>
				<li><a href="<?php echo site_url();?>"> <?php echo $this->lang->line('app_home');?> </a></li>
				<li><a href="<?php echo base_url('app/aboutus');?>"><?php echo $this->lang->line('app_whoim');?></a></li>
				<li><a href="<?php echo base_url("app/contactus");?>"><?php echo $this->lang->line('app_contactus');?></a></li>
				<li><a href="<?php echo base_url('app/ads');?>"><?php echo $this->lang->line('app_advwithus');?></a></li>
				<li><a href="<?php echo base_url('app/info');?>"><?php echo $this->lang->line('app_theway');?></a></li>
				<li><a href="<?php echo base_url('app/services');?> "><?php echo $this->lang->line('app_service');?></a></li>
				<li><a href="<?php echo base_url('app/job');?>"><?php echo $this->lang->line('app_jop');?></a></li>
			</ul>
			<div class="lft puertoSearch">
				<form method="get" name="formsearch" action="<?php echo base_url('post/search');?>">
					<span></span>
					<input type="text" name="searchinput" placeHolder="ابحث ..." class="rgt" />
					<input type="submit" value="" class="lft" />
				</form>
			</div>
			<div class="clr"></div>
		</div>
		
		<div class="puertoHeaderCenter">
			<div class="lft" style="width:740px;padding:15px 0 0 3px;">
			<?php  echo modules::run('ads/banner',103,'ds5&f46#d5s@f4@#0od$0w3fdgdf'); ?>
			</div>
			<div class="rgt" style="width:222px;padding:30px 10px 0 0;">
				<img src="<?php echo $base?>/images/logo.png" />
			</div>
			<div class="clr"></div>
		</div>
		
		<div class="puertoHeaderBtm">
			<ul>
				<li><a href="<?php echo site_url();?>" class="home active"></a></li>
				<li class="li"></li>
				<li><a href="<?php echo base_url('post/category');?>"><?php echo $this->lang->line('app_articles');?></a></li>
				<li class="li"></li>
				
				<li><a href="<?php echo base_url('post/category/2');?>"><?php echo $this->lang->line('app_link_polices');?></a></li>
                <li class="li"></li>    
				
				
				<li><a href="<?php echo base_url('post/category/3');?>"><?php echo $this->lang->line('app_link_economic');?></a></li>
                <li class="li"></li>    
                
                <li><a href="<?php echo base_url('post/category/4');?>"><?php echo $this->lang->line('app_link_sport');?></a></li>
                <li class="li"></li>    
                
                <li><a href="<?php echo base_url('post/category/5');?>"><?php echo $this->lang->line('app_link_tecnlogy');?></a></li>
                <li class="li"></li>    
				
				
				
								 
			<li><a href="<?php echo base_url('video/category');?>"><?php echo $this->lang->line('app_video');?></a></li>
				<li class="li"></li>
				<li><a href="<?php echo base_url('app/register');?>"> <?php echo $this->lang->line('app_newmemeber');?>  </a></li>
				<li class="li"></li>
			</ul>
		</div>
	
	</div>
	
	<!-- بداية وسط الصفحة -->
	
	<div class="puertoAds">
		<span class="adsTitle rgt"> <?php echo $this->lang->line('app_advert');?> </span>
		<span class="adsCnt rgt">
			<ul id="js-news" class="js-hidden">
				<!--<li><a href="#">Slider الانتهاء من تصميم عارض الصور المنزلقة Slideshow</a></li>
				<li><a href="#">تصميم قالب مدونة - الجزء 3</a></li>
				-->
				<?php
                 echo modules::run('post/adspost');
                ?>
			</ul>
		</Span>
		<div class="clr"></div>
	</div>
	
	<div id="puertoHome">
		
		<!-- القائمة الخاصة بعرض أخر التدوينات -->
		<div class="rgt" style="width:650px;">
		
		 
	
		  <?php
      echo @$container;
      ?>
		
		
		</div>
		
		<!-- القائمة الموجودة على اليمين -->
		<div class="lft" style="width:310px;">
			
			     <div class="puertoLftTitle"><span> <?php echo $this->lang->line('app_slink');?></span></div>
            <div class="puertoLftCnt"  >
               <!-- //بلا -->
             <div align="center">
            <a href="<?php echo $fp['Facebook'];?>" target="_blank"> <img src="<?php echo $base?>/images/facebook-icon.png"> </a>   
           <a href="<?php echo $fp['google+'];?>" target="_blank"><img src="<?php echo $base?>/images/google-icon.png"> </a>   
            <a href="<?php echo $fp['Twitte'];?>" target="_blank"><img src="<?php echo $base?>/images/twitter-icon.png">  </a>  
            <a href="<?php echo $fp['Youtube'];?>" target="_blank"><img src="<?php echo $base?>/images/youtube-icon.png"></a>
           </div>    
               <!-- //login -->
            </div>  
			
			
			
			
			<div class="puertoLftTitle"><span> <?php echo $this->lang->line('app_login');?>  </span></div>
            <div class="puertoLftCnt"  >
               <!-- //login -->
                 <?php 
  //RP    FP   PP
  $optionLogin=array(
  'Page_Register'=>base_url('app/register'),
   'Page_Password'=>base_url('app/restorpass'),
    'Page_Profile'=>base_url('app/profile'),
    'page_Logout'=>base_url('app/logout'),
  );
           
  echo modules::run('api/login_form','ds5&f46#d5s@f4@#0od$0w3fdgdf',$optionLogin);
  ?>
               
               <!-- //login -->
            </div>
			
			
			
			
		      <div class="puertoLftTitle"><span> <?php echo $this->lang->line('app_poll');?></span></div>
            <div class="puertoLftCnt"  >
               <!-- //login -->
                 <?php 
   echo modules::run('poll/poll','ds5&f46#d5s@f4@#0od$0w3fdgdf'); 
  ?>
               
               <!-- //login -->
            </div>	
			
			
			
			   <div class="puertoLftTitle"><span>  <?php echo $this->lang->line('app_maillist');?></span></div>
            <div class="puertoLftCnt"  >
               <!-- //login -->
                 <?php 
  echo modules::run('api/email_list','ds5&f46#d5s@f4@#0od$0w3fdgdf','app/elist');

  ?>
               
               <!-- //login -->
            </div>  
            
			
		
		
		
		     <div class="puertoLftTitle"><span>  <?php echo $this->lang->line('app_counter');?>    </span></div>
            <div class="puertoLftCnt"  >
               <!-- //login -->
                 <?php 
 echo modules::run('api/hitCounter','ds5&f46#d5s@f4@#0od$0w3fdgdf');
                    ?>
               
               <!-- //login -->
            </div>  
            
			
			
			
			
			
			<div class="puertoLftTitle"><span> <?php echo $this->lang->line('app_ads');?></span></div>
			<div class="puertoLftCnt" style="font-size:0;">
			<?php  echo modules::run('ads/banner',104,'ds5&f46#d5s@f4@#0od$0w3fdgdf'); ?>
			</div>
			
			
			<div class="puertoLftTitle" style="margin-top:25px;"><span>  <?php echo $this->lang->line('app_whoonline');?> </span></div>
			<div class="puertoLftCnt" style="padding:0;">
			    <?php
			 echo modules::run('api/visitorOnline','ds5&f46#d5s@f4@#0od$0w3fdgdf');
                  ?>
			</div>
			
			<div class="puertoLftTitle" style="margin-top:25px;"><span> <?php echo $this->lang->line('app_pagefacebook');?></span></div>
			<div class="puertoLftCnt" style="font-size:0;">
			<!--<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FEgyptianProgrammers&amp;width&amp;height=290&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true&amp;appId=502353919849267" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:290px;" allowTransparency="true"></iframe>
 		-->
 		<img src="<?php echo $base?>/images/fp.gif"/>
 			</div>
			
			 
			 
			 
			 <div class="puertoLftTitle" style="margin-top:25px;"><span>    <?php echo $this->lang->line('app_tags');?></span></div>
            <div class="puertoLftCnt" style="padding:0;">
                <?php
              echo modules::run('post/tags');
                  ?>
                   
            </div>
			 
			
			
			 
			
		</div>
		
		<div class="clr"></div>
		
	</div>
		
</div>


<div id="puertoBtmFooter">
	Programmed  By Osama Salama. &copy; 2014 - 2015 All rights reserved.
</div>


</body>
</html>