<?php
$lang['posts_tag'] ="  ألاوسمة";
$lang['posts_addTags'] =" وسم جديد";
$lang['posts_add'] ="  مقال - خبر جيد";
$lang['posts_edit'] ="تعديل";
$lang['posts_comments'] ="التعليقات";
$lang['posts_save'] ="حفظ";
$lang['posts_msgadd'] ="تم حفظ البيانات بنجاح";
$lang['posts_msgerror'] =" البيانات مسجلة من قبل";
$lang['posts_ID'] ="مسلسل";
$lang['posts_title'] ="ألاخبار -المقالات";
$lang['posts_delete'] ="حذف";
$lang['posts_cat'] ="القسم";
$lang['posts_btn_search'] ="  بحث ";
$lang['posts_btn_add'] ="تاريخ ألاضافة";
$lang['posts_date'] ="تاريخ ألاضافة";
$lang['posts_search_msg'] ="   نأسف لعدم وجود نتائج";
$lang['posts_tagsname']="أسم الوسم";
$lang['posts_error2']="من فضلك أختار القسم";
$lang['posts_name']="عنوان المقال";
$lang['posts_name_en']="عنوان المقال- اللغة الثانية ";
$lang['posts_pic']=" تحميل صورة";
$lang['posts_picsmall']="  صورة مصغرة  ";
$lang['posts_picstitle']="  تعليق علي الصورة ";
$lang['posts_tagsname_missing']="أسم الوسم مفقود";
$lang['posts_author']="الكاتب";
$lang['posts_content']="المحتوي";
$lang['posts_content_en']="المحتوي - اللغة الثانية";
$lang['posts_validate_title']="عنوان المقال مفقود";
$lang['posts_validate_pic']="نوع الصورة غير مسموح بة";
$lang['posts_validate_authur']="اسم الكاتب مفقود";
$lang['posts_back']="  عودة";
$lang['posts_validate_cat']="القسم مفقود";
$lang['posts_comment_name']="ألاسم";
$lang['posts_comment_email']="البريد الالكتروني";
$lang['posts_comment_status']="الحالة";
$lang['posts_comment_enable']="مفعل";
$lang['posts_comment_disabled']="غير مفعل";
$lang['posts_comment_content']="المحتوي";
$lang['posts_comment_active']="تفعيل";
$lang['posts_comment_deactive']="إلغاء التفعيل";
$lang['posts_hint']="   افصل بين الوسوم بفواصل  ";
$lang['posts_choosetag']="اختر من الوسوم الأكثر استخداماً";
$lang['posts_fullscreen']="لعرض المحرر كامل  من قائمة العرض اختار ملء الشاشة";
$lang['posts_addtags']=" أضف ";
?>