<?php
$lang['key_1'] = "Im speak English";


$lang['contactus_title'] ="Contact Us";
$lang['contactus_name'] ="Name";
$lang['contactus_email'] ="E-Mail";
$lang['contactus_site'] =" WebSite";
$lang['contactus_msg'] ="Message";
$lang['contactus_btn_send'] =" Send";
$lang['contactus_captcha'] ="verification code";
$lang['contactus_messgae_send'] ="The message was sent. Will be reply you as soon as";
$lang['contactus_message_fail'] ="Failed to send the message .. Please try again later";
$lang['contactus_input_name']="Name is missing";
$lang['contactus_input_email']="Email is missing";
$lang['contactus_input_msg']=" Message is missing";
$lang['contactus_input_captcha']="Please enter the verification code";
$lang['contactus_input_required']="Required";


$lang['maillinglist_titles']="Mailing List";
$lang['maillinglist_subcribe']="Subscribe";
$lang['maillinglist_unsubcribe']="UnSubscribe";
$lang['maillinglist_btnsubcribe']=" OK";
$lang['maillinglist_add_sucess']="E-mail has been added to the mailing list";
$lang['maillinglist_add_fail']="E-mail";
$lang['maillinglist_remove_subcribe']="UnSubscribe  ";
$lang['maillinglist_remove_msg1']="Was sent an email to confirm the deletion of e-mail";
$lang['maillinglist_remove_msg2']="Email already registered";
$lang['maillinglist_remove_msg3']="Link is incorrect .. please make sure you link required";
$lang['maillinglist_remove_msg4']="E-mail has been deleted";
$lang['maillinglist_remove_msg5']="E-mail have not registered";
$lang['maillinglist_add_msg5']="Mail has been added to the mailing list";
$lang['maillinglist_subject_email']='Sold-mail - delete the e-mail confirmation from the mailing list';
$lang['maillinglist_msg_email']='Click on the link to activate delete E-Mail ..';
$lang['maillinglist_msg_empty']='';


$lang['member_login_username']='Email  ';
$lang['member_login_password']='Password';
$lang['member_login_btn']='Login';
$lang['member_login_Errormsg']='invalid login';
$lang['member_email']='Email';
$lang['member_country']=' Country';
$lang['member_regLink']='Sign up now';
$lang['member_forgetpass']="Can't access your account?";
$lang['member_gender']='Gender';
$lang['member_gender_male']='male';
$lang['member_gender_female']='Female';
$lang['member_pic']='Avatar';
$lang['member_password']='Password';
$lang['member_cpassword']='Confirm Password';
$lang['member_addnew']='Data has been saved';
$lang['member_profile']='Profile';
$lang['member_logout']='Sing Out';
$lang['member_profiles']='Sing Out';
$lang['member_msg_welcome']=" Welcome/  ";
$lang['mem_name']=" Name";
$lang['mem_password']="Password";
$lang['mem_cpassword']="Confirm Password";
$lang['mem_country']=" Country";
$lang['mem_gender_male']="male";
$lang['mem_gender_female']="Female";
$lang['mem_nofication']="Subscribe been successfully ";
$lang['mem_missing_name']='Name missing';
$lang['mem_missing_email']='E-mail is missing or invalid';
$lang['mem_missing_username']='Username is missing';
$lang['mem_missing_password']=' Password is missing';
$lang['mem_missing_cpassword']=' Password is not equal to the Confirm Password';
$lang['mem_msg_add']="User data has been added successfully";
$lang['mem_msg_error']="Failed to add data or by registered mail";
$lang['mem_msg_errorpic']="Image type is not allowed";
$lang['mem_email_msg']="Activate the subscription on the site";
$lang['mem_email_links']="Copy the link in your browser to activate the accountك";
$lang['mem_activebyadmin']= "Data were recorded organic successfully. Account will be activated after reviewing the management of the site";
$lang['mem_activebyemail']= " Data were recorded organic successfully .. message has been sent to you by email to activate your account on the site";
$lang['mem_activeok']="Your subscription was activated at the site successfully";
$lang['mem_restorepass1']="Please enter your email ";
$lang['mem_restorepass3']=" Send";
$lang['mem_restoresubject']="Sold-mail - confirmation to reset your password";
$lang['mem_restoremsg1']="Click on the link to activate your new password .. or ignore this message if you do not want to change the password";
$lang['mem_restoremsg2']="The new password";
$lang['mem_restoremsgok']=" Was sent a link to activate your new password to your email .. Check your password to confirm";
$lang['mem_changepassok']="Password has been changed successfully";
$lang['mem_updateAccount']=" Data has been saved successfully";

?>