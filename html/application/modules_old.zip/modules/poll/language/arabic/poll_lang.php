<?php
$lang['poll_list'] = " ألاستبيان";
$lang['poll_new'] = " إستبيان جديد";
$lang['poll_edit'] = "  تعديل ";
$lang['poll_question1'] = "  السؤال ";
$lang['poll_question2'] = "  السؤال -اللغة الثانية ";
$lang['poll_status'] = "  الحالة ";
$lang['poll_delete'] = "  حذف  ";
$lang['poll_save'] = "  حفظ ";
$lang['poll_option'] = "  الخيار ";
$lang['poll_option2'] = "  الخيار -اللغة الثانية   ";
$lang['poll_status_active'] = "  مفعل ";
$lang['poll_status_dactive'] = "  غير مفعل ";
$lang['poll_message_add'] = "  تم حفظ البيانات بنجاح ";
$lang['poll_message_found'] = "  سؤال ألاستبيان مسجل من قبل ";
$lang['poll_ID'] = "  مسلسل  ";
$lang['poll_mis_question'] = "   السؤال مفقود  ";

////////////////////
$lang['poll_site_send']="تصويت";
$lang['poll_site_view']="عرض النتائج";
$lang['poll_site_msg1']="من فضلك اختار إجابة من الاستبيان";
?>