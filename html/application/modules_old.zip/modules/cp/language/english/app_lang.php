<?php
$lang['app_welcome'] = "Welcome :";
$lang['app_modules'] = "Plugins -Modules ";
$lang['app_language'] = "Languages";
$lang['app_signout'] = "Sign Out";
$lang['app_home'] = "Preview WebSite";
$lang['app_chart'] = "Statistics";
$lang['app_options'] = "Settings";
$lang['app_memebers'] = "Members - Supervisors";
$lang['app_filesys'] = "File Manager";
$lang['app_msmail'] = "E-mail - Mailing List";
$lang['app_vistors'] = "Visitors";
$lang['app_backup'] = "BackUp Database";
$lang['app_help'] = "Help";
$lang['app_mailbox'] = "Inbox";
$lang['app_notify'] = "Notifications";

$lang['app_colorA'] = "Default";
$lang['app_colorB'] = "Black";
$lang['app_colorC'] = "Orange";




$lang['options_message']="Settings have been updated successfully"; 
$lang['options_title']="Settings"; 
$lang['options_web_cache']="Using Cache"; 
$lang['options_web_cache_time']="Cache time in minutes"; 
$lang['options_notification_time']="Notifications remove after number of date"; 
$lang['options_web_title']="WebSite Title"; 
$lang['options_capacity']="Hosting Size"; 
$lang['options_web_status']=" Close Site"; 
$lang['options_web_status_message']="Message Close Site"; 
$lang['options_title_metadata']=" MetaData(Seo)"; 
$lang['options_title_socialnetwork']="Social networking"; 
$lang['options_title_email']="  Mail Server Settings"; 
$lang['options_mail_server']="Mail Server"; 
$lang['options_email_received']="Email - receive messages"; 
$lang['options_mail_sendmail']=" SendMail Path"; 
$lang['options_mail_sender']="Name of the Sender ";
$lang['options_mail_smtp']="( SMTP ) Email Server- for Send Email "; 
$lang['options_mail_user']="( SMTP ) Username"; 
$lang['options_mail_pwd']="( SMTP ) Password"; 
$lang['options_mail_port']="SMTP -  Port";

$lang['options_encryption']="Encryption"; 
$lang['options_encryptionselect1']="No-Encryption"; 
$lang['options_mail_format']="Message Format"; 

$lang['options_sendbutton']="Send Data"; 


$lang['backup_title']="Backup database";
$lang['backup_select']="Choose the type of database file";
$lang['backup_select2']="Email";
$lang['backup_btn1']="Download";
$lang['backup_btn2']="Send To Email";
$lang['backup_btn3']="Send";
$lang['backup_msgok']="Send backup to email successfully";
$lang['backup_msgerror']="Failed to send E-Mail";

$lang['visitor_title']='Visitor';
$lang['visitor_counter_title']='Visitor Options';

$lang['visitor_select_title']='---- Select ----';
$lang['visitor_id']='ID';
$lang['visitor_os']='OS';
$lang['visitor_browser']='Browser';
$lang['visitor_mobile']='Mobile';
$lang['visitor_country']='Country';
$lang['visitor_status']='Status';
$lang['visitor_date']='Date';






 
$lang['visitors_options_selectcounter']=" Choose Counter Visitors ";
$lang['visitors_options_selectcustom']="  Code ";
$lang['visitors_options_entercode']="  Enter Code Here ";
$lang['visitors_options_tempavalible']=" Templates available";
$lang['visitors_options_counternumber']="Counter Now";
$lang['visitors_options_discover']=" Discover IP/Country ";
$lang['visitors_options_vistortmp']=" Template Who online";
$lang['visitors_options_default']=" Counter Visitors  ";
$lang['visitors_options_online']="  Settings Who's Online  ";
$lang['visitors_options_selectmp1']=" Default Template ";
$lang['visitors_options_selectmp2']="(Enter Code)  ";
$lang['visitors_options_discover1']=" Local Database ";
$lang['visitors_options_discover2']=" WebService ";
 




$lang['masmail_inbox']=" Inbox ";
$lang['masmail_sendmail']="Send Email";
$lang['masmail_maillist']="Mailing List";
$lang['masmail_sendmaillist']="Contact Mailing List";
$lang['masmail_countactus']="Contact Us";
$lang['masmail_options']="Settings Inbox and Mailing List";

$lang['masmail_sendmail_to']="E-mail address";
$lang['masmail_sendmail_subject']="Subject";
$lang['masmail_sendmail_message']="Message";
$lang['masmail_sendmail_attach']="attach File";
$lang['masmail_sendmail_btn']="Send E-mail";
$lang['masmail_sendmail_messageok']="Mail was sent successfully";
$lang['masmail_sendmail_messageerror']="Failed to send mail.";

$lang['masmail_sendmail_errorTo']="E-mail is missing or incorrectly";
$lang['masmail_sendmail_errorSubject']="Subject missing or greater than the area of ​​field";  
$lang['masmail_sendmail_errorMsg']="E-mail message is missing  "; 

$lang['masmail_maillist_title1']="Add E-mail to the mailing list  "; 

$lang['masmail_maillist_email']="E-mail"; 
$lang['masmail_maillist_btn1']="Save Data"; 
$lang['masmail_maillist_titlep']=" Data mailing list";
$lang['masmail_maillist_sendmail']=" Send message";  
$lang['masmail_maillist_datemsg']="Date ";

$lang['masmail_maillist_delemail']=" Delete E-mail  ";
$lang['masmail_maillist_erroraddmaillist']=" Invalid email or recorded by  ";

$lang['masmail_maillist_addmailok']="E-mail has been added to the mailing list";
$lang['masmail_maillist_addmailerror']="Failed to add E-mail";

$lang['masmail_maillist_backtomaillist']="Back to the mailing list";

$lang['masmail_maillist_btn_send']="  Send ";

$lang['masmail_maillist_btn_chartsend']="Statistics messages";

$lang['masmail_maillist_num_msg']="Number of messages";
$lang['masmail_maillist_num_send']="  Message sent ";
$lang['masmail_maillist_status_send']=" connection status ";
$lang['masmail_maillist_status_on']=" Online  ";
$lang['masmail_maillist_status_off']="  Offline ";
$lang['masmail_maillist_on']="Continuous";
$lang['masmail_maillist_off']="Stop";
$lang['masmail_maillist_cancel']="Cancel";

$lang['masmail_options_incomeemail']=" E-mail to receive messages";
$lang['masmail_options_allow_notifications']="allow notification";
$lang['masmail_options_allow_formcountactus']="Using form contact us ";
$lang['masmail_options_allow_infobox']="Using Contact Info";
$lang['masmail_options_allow_infobox_title']="  Contact Info   ";
$lang['masmail_options_order_box_up']="Contact Info up form contact us";
$lang['masmail_options_order_box_down']="Contact Info down form contact us";

$lang['masmail_options_maillist_allowform']=" Using form mailing list";
$lang['masmail_options_maillist_allowcode']="Using Code";
$lang['masmail_options_maillist_codedata']=" Code ";
$lang['masmail_options_maillist_notifications']="allow notification ";
$lang['masmail_options_maillist_deletelinks']=" Delete Email by active link";

$lang['masmail_viewmsg']="Message";
$lang['masmail_delete']=" Delete   ";


$lang['masmail_msg_name']=" Name";
$lang['masmail_msg_email']="  E-mail";
$lang['masmail_msg_site']=" Website";
$lang['masmail_msg_content']="Message";
$lang['masmail_msg_replay']=" Reply to  Message";
$lang['masmail_msg_title']="  Subject";
$lang['masmail_msg_content_replay']="Message";
$lang['masmail_msg_send']=" Send Message";
$lang['masmail_msg_clear']="  Rest ";
$lang['masmail_msg_back']="  Back ";
$lang['masmail_msg_delete']=" Delete Message";

$lang['masmail_msg_list_more']=" More";
$lang['masmail_msg_list_empty']=" No New Message Found";


$lang['media_title']="Files-Images Manager";
$lang['media_options']="Files-Images Options";
$lang['media_file_type']="File extensions allowed";
$lang['media_upload_options']=" Upload";
$lang['media_upload_options_type1']=" Standard ";
$lang['media_upload_options_type2']="Ajax";
$lang['media_upload_thumbnail_title']="Image Setting";
$lang['media_upload_thumbnail']="Thumbnail images";
$lang['media_upload_thumbnail_handel']="  Type of Thumbnail  ";
$lang['media_upload_thumbnail_orginal']="Thumbnail Origine File (one File)";
$lang['media_upload_thumbnail_copy']="Thumbnail Copy From File(Two File)";
$lang['media_upload_thumbnail_width']="Width";
$lang['media_upload_thumbnail_height']="Height ";
$lang['media_upload_filename_options']="Processing filenames";
$lang['media_upload_filename_byauto']="No Change";
$lang['media_upload_filename_bytime']=" Auto Name";

$lang['media_upload_newdir']="New Folder  ";
$lang['media_upload_updir']="  Up Level ";
$lang['media_upload_deldir']=" Delete selected Files ";
$lang['media_upload_downdir']="  Download Selected Files ";
$lang['media_upload_uploadfile']=" Upload";
$lang['media_upload_title']=" Uploads Files";
$lang['media_upload_success']=" The file was Uploaded successfully";
$lang['media_upload_error']="Failure to Uploaded the file";
$lang['media_upload_listfile']="File Link";
$lang['media_upload_listimg']="Link Thumbnail";
$lang['media_formadd']="Insert the file";


// Category Manager
$lang['cat_title']="Category Manager ";
$lang['cat_new']="New Category";
$lang['cat_name1']="Category name";
$lang['cat_name2']="Category name (Foregin language) ";
$lang['cat_parent']=" Parent";
$lang['cat_img']="  Category Image";
$lang['cat_save']=" Save Data";
$lang['cat_update']=" Edit data ";
$lang['cat_ID']=" ID  ";
$lang['cat_edit']="Edit Category";
$lang['cat_delete']=" Delete Category";
$lang['cat_addok']="Category was add successfully";
$lang['cat_adderror']="  Failure to add Category or found before ";
$lang['cat_archive']=" Category List";
$lang['cat_nopic']="No Image";
$lang['cat_back']=" Back To Category";
$lang['cat_noName']="Category Name is Missing ";
$lang['cat_module']=' Link With Module';

$lang['mem_title']="Members - Supervisors";
$lang['mem_newuser']=" New Member";
$lang['mem_edituser']=" Edit  Member ";
$lang['mem_options']=" Options";
$lang['mem_listuser']="Registered Members";
$lang['mem_name']=" Name";
$lang['mem_email']=" Email ";
$lang['mem_gender']=" Gender";
$lang['mem_pic']=" Image";
$lang['mem_role']="roles";
$lang['mem_datereg']="Date";
$lang['mem_active']="Enabled Memebers";
$lang['mem_on']=" Enabled";
$lang['mem_off']="disabled";
$lang['mem_status_acount']="Status";
$lang['mem_viewinfo']="Preview";
$lang['mem_btn_delete']="Delete";
$lang['mem_btn_dactive']="disabled Memebers";
$lang['mem_country']=" Country";
$lang['mem_username']=" UserName  ";
$lang['mem_password']=" Password  ";
$lang['mem_gender_male']="Male";
$lang['mem_gender_female']="Female";
$lang['mem_role_user']=" User";
$lang['mem_role_admin']="Manager";

$lang['mem_missing_name']='Name missing';
$lang['mem_missing_email']='E-mail is missing or invalid';
$lang['mem_missing_username']='Username is missing';
$lang['mem_missing_password']='  Password is missing';
$lang['mem_msg_add']="User data has been added successfully";
$lang['mem_msg_error']="Failed to add data or by registered mail";

$lang['mem_option_activeuser']='activate members through';
$lang['mem_option_webcam']='Using Service Camera (WebCam)';
$lang['mem_option_avatar']='Using Service Avatars (Avatar)';
$lang['mem_option_notifications']=' notifications when recording members ';
$lang['mem_option_activeby_auto']='ِِ Auto';
$lang['mem_option_activeby_admin']=' By Manager';
$lang['mem_option_activeby_email']=' By Email';
$lang['mem_login']='  Enter';
$lang['mem_login_errormsg']=" Error Login. ";
$lang['mem_login_title']="Login";
$lang['mem_option_reg']="Anyone can register on the site";

$lang['chart_vistors']="Visitors Statistics";
$lang['chart_size']=" Statistics available space "; 
$lang['chart_memory']=" The size of the memory used"; 
$lang['chart_info']=" Information Server ";
$lang['chart_members']=" Statistics subscribers and visitors ";  
$lang['chart_ossystem']=" OS";
$lang['chart_phpversion']="PHP Version ";
$lang['chart_mysqlversion']="MySql Version ";
$lang['chart_serverversion']=" Server";
$lang['chart_sizedb']="Database Size";
//$lang['chart_extentions']="";
$lang['chart_foldermedia']="Folder size of downloaded files";
$lang['chart_vistornow']="Visitors Online";
$lang['chart_membernow']="Members Online";
$lang['chart_membermanagernum']="managers";
$lang['chart_membernum']=" registered members";
$lang['chart_memberactive']="members waiting activation";

$lang['chart_usedsize']='Used';
$lang['chart_allsize']='Free';

$lang['plugin_article']="Articles - News ";
$lang['plugin_media']="Multimedia ";
$lang['plugin_poll']="Polls";
$lang['plugin_advert']="Ads";



?>


