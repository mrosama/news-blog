<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cp extends MX_Controller  {

   const VIEWPATH='../../cp/views/cp/';
   
   
   
  public function __construct()
       {
          
           
            parent::__construct();
            $api = $this -> load -> library('apiservices');
             $this->load->model('admin_model');
         //  $api->CP_Auth(1,true,'No direct script access allowed');
           $this->load->library('form_validation');
          //  $this->load->library('session');
           // $this->db->db_debug = false;
            $this->form_validation->CI =& $this;
                $this->form_validation->set_error_delimiters('<div class="uk-alert uk-alert-danger font_deafult dirTemplate">', '</div>');
            
            // Your own constructor code
//echo base_url("images/icons/edit.png");
   //  $this->lang->load('app', 'english');
  ////////////////////////////////////////////////////////// 
 @$files = @glob('assets/tmp/*.zip');
   if (!@$files) {
   //  continue; // do nothing if error or no files match
 }

 if(is_array($files)){
 foreach(@$files as $file)
 {
     $exp=time()-300;
    $ftime=  @basename(@$file,".zip");
    if($ftime < $exp){
        @unlink($file);
    }
     
 }
 }
 ////////////configure language/////////////////////////////////  
   
 @$session_language = @$this->session->userdata('cplang');  
 @$session_style = @$this->session->userdata('cpstyle');    
  $TPL_Config = $this -> config -> item('Template_Type');
    
 if($session_language!=''){
   $this->lang->load('app', $session_language);
  } else {
      
      switch($TPL_Config){
          case 'A':
            $this->lang->load('app', 'arabic');
            $this->session->set_userdata('cpstyle', 'ar');  
          break;
          
          case 'B':
            $this->lang->load('app', 'english');
            $this->session->set_userdata('cpstyle', 'en'); 
          break;
          
          default:
            $this->lang->load('app', 'arabic');
            $this->session->set_userdata('cpstyle', 'ar'); 
          break;
           }
     //end switch
     
 } 
  
//$this->lang->load('app', 'arabic');
    
    
}
       
       
       
public function setlang(){
        $cpstyle=null;  
$api = $this -> load -> library('apiservices');
$api->CP_Auth(1,true,'No direct script access allowed');
 $TPL_Config = $this -> config -> item('Template_Type');
   
  
  if($TPL_Config != 'A' && $TPL_Config!='B'){

$lang = $this->uri->segment(3);
if($lang=='arabic'){
     $cpstyle='ar';
}
if($lang=='english'){
 $cpstyle='en';
}  
$CPLang=array('cplang'=>$lang,'cpstyle'=>$cpstyle);
 
 $this->session->set_userdata($CPLang);
 //print_r($CPLang);

  
   }  
 redirect('cp/admin','location');  
   
     
   }    
       
       
       

  public function admin()
    {
        
   $data=array();   
$api = $this -> load -> library('apiservices');
$api->CP_Auth(1,true,'No direct script access allowed');

$this->load->model('admin_model');

  $data['chart_size']=$this->admin_model->getChartSize();
  $data['website_info']=$this->admin_model->getsiteInfo();
  $data['member_info']=$this->admin_model-> getmemebersInfo();
  $data['visitors_info']=$this->admin_model-> getChartVisitor();
        
         
 $this->layout->view(Cp::VIEWPATH.'admin', $data); 
        
    }




public function options()
    {
  $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
 
   
        
        $data=array();
        
        // $this->lang->load('app', 'arabic');
        ///////////////////////
        
        $this->load->model('admin_model');
        
      
        
          
        
       if($this->input->post('IsPost_options')=="y"){
           
          $checkdata= $this->admin_model->setOptions();
           
           if($checkdata==true){
             $data['options_update']=true; 
               
           }
           
       }
        
        
        
          $rows=$this->admin_model->getOptions();
      
        $data['options_rows']=$rows;
        
        
        
        
        
        
        ////////////////////////////
        
        $this->layout->view(Cp::VIEWPATH.'options', $data);  
       
       
       
    }


    public function index()
    {
      $data=array();
       
        if($this->session->userdata('IUser_role')=='1'){
            
            redirect('cp/admin','location');
        }
       
       
         $this->load->model('admin_model');
        
        if($this->input->post('IsPost_login')=="y"){
           $rs= $this->admin_model->Cp_Login();
            
            $data['result_login']=$rs;
            
            
        }
 
      
    
      $this->load->view(CP::VIEWPATH.'index',$data);
       
    }



  public function backup()
    {
           $data=array();
         
     $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
            
     $this->load->library('form_validation');
    $this->form_validation->CI = $this;
    
         $this->load->model('admin_model');
        
         if($this->input->post('IsPost_dbbackup')=="y"){
             
             $this->form_validation->set_rules('mail_send', 'invalid_email','required|valid_email');
             if ($this->form_validation->run() != FALSE){
             
             $email_data=$this->admin_model->backup_db_email();
             
               if($email_data==true){
             $data['backup_email']='send'; 
               
            } else {
               $data['backup_email']='error'; 
               
           }
           }else {
             $data['backup_email']='error';   
               
           }




             
         }
      
        
          
        
       if($this->input->post('IsPost_backup')=="y"){
           
          $checkdata= $this->admin_model->backup_db();
           
         /*  if($checkdata==true){
             $data['options_update']=true; 
               
           }*/
           
       }
        
         
         
         
         
         
         
         
         
       
       $this->layout->view(Cp::VIEWPATH.'backup', $data);  
    }










  public function signout()
    {
        
     $this->load->model('admin_model');
    
      $this->admin_model->Cp_logout();
    }





  public function visitor()
    {
   $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
        
        $seg = $this -> uri -> segment(3);
        $this->load->model('admin_model');
       
       
        $data=array();
      
     
     
      ///////////////options
      if( $seg=='options'){
        if($this->input->post('IsPost_visitor')=="y"){
           
          $checkdata= $this->admin_model->setOptionsVistors();
           
           if($checkdata==true){
             $data['vistors_update']=true; 
               
           }
           
       }
        
        
        
          $rows=$this->admin_model->getOptionsVistors();
      
        $data['vistors_rows']=$rows;
     
     
      } else {
          
           $result= $this->admin_model->getVisitors();
     
   $data['Rows_visitors']   =  $result['Rows_visitors'];
   $data['Total_visitors']  =  $result['Total_visitors'];
   $data['Paging_visitors'] =  $result['Paging_visitors'];
          
      }
     
     
     
     
         $this->layout->view(Cp::VIEWPATH.'vistors', $data);  
    }




  public function masmail(){
     $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
      $data=array();
       $param = $this -> uri -> segment(3);
         
     
       
       $this->load->model('admin_model');
        if($param=='sendemail'){
        if($this->input->post('IsPost_sendmail')=="y"){
            
            //check input
            $config = array(
               array(
                     'field'   => 'to', 
                     'label'   => $this->lang->line('masmail_sendmail_errorTo'), 
                     'rules'   => 'required|valid_email'
                  ),
               array(
                     'field'   => 'subject', 
                     'label'   => $this->lang->line('masmail_sendmail_errorSubject'), 
                     'rules'   => 'required|max_length[90]'
                  ),
               array(
                     'field'   => 'msg', 
                     'label'   => $this->lang->line('masmail_sendmail_errorMsg'), 
                     'rules'   => 'required'
                  )  
              
            );
            $check_return1=$api->CheckControl($config);
            
            //end checkinput
            
          if($check_return1==true){
          $checksend= $this->admin_model->masmail_sendmail();
           
           if($checksend==true){
             $data['email_send']='send'; 
               
           } else {
               
              $data['email_send']='error';  
           }
          }
           
           
       }
       
       }
       /////////////////////////////////////////////////////////////
       
       
       
     if($param=='mailinglist'){
        $send_inbox = $this -> uri -> segment(4);
       
       
       
       
        if($this->input->post('IsPost_addEmail')=="y"){
        $config2 = array(
               array(
                     'field'   => 'to', 
                     'label'   => $this->lang->line('masmail_maillist_erroraddmaillist'), 
                     'rules'   => 'required|valid_email'
                  )
                
              
            );
       
            $return_check= $api->CheckControl($config2);
            if($return_check==true){
            $check_add= $this->admin_model->masmail_addEmail();
            
             if($check_add==true){
             $data['email_add']='add'; 
               
           } else {
               
              $data['email_add']='error';  
           }
            }
            
            
        }
       
       ///////////////
       
         if($this->input->post('IsPost_delEmail')=="y"){
             
             $this->admin_model->delete_maillist();
             
         }
       
       
      
   $result= $this->admin_model->getmaillist();
     
   $data['Rows_maillist']   =  $result['Rows_maillist'];
   $data['Total_maillist']  =  $result['Total_maillist'];
   $data['Paging_maillist'] =  $result['Paging_maillist'];
   ///////////////////////////////
   
   
   
    
        }


       ///////////////////////////////////////////////////////////
       
       
       
       
        if($param=='singleemail'){
            
            if($this->input->post('IsPost_backmaillist')=="y"){
                
                redirect("cp/masmail/mailinglist");
            }
            
       //////////////////
        if($this->input->post('IsPost_sendmailone')=="y"){
            
            //check input
            $config = array(
               array(
                     'field'   => 'to', 
                     'label'   => $this->lang->line('masmail_sendmail_errorTo'), 
                     'rules'   => 'required|valid_email'
                  ),
               array(
                     'field'   => 'subject', 
                     'label'   => $this->lang->line('masmail_sendmail_errorSubject'), 
                     'rules'   => 'required|max_length[90]'
                  ),
               array(
                     'field'   => 'msg', 
                     'label'   => $this->lang->line('masmail_sendmail_errorMsg'), 
                     'rules'   => 'required'
                  )  
              
            );
            $check_return1=$api->CheckControl($config);
            
            //end checkinput
            
          if($check_return1==true){
          $checksend= $this->admin_model->masmail_sendmail();
           
           if($checksend==true){
             $data['email_send']='send'; 
               
           } else {
               
              $data['email_send']='error';  
           }
          }
           
           
       }
       
       //////////////////
            
            
            $IuserData= $this->admin_model->getinfoEmail();
            $data['User_Email']=$IuserData['maillist_email'];
            
           
            
        }
 /////////////////////
 if($param=='contactus'){
     
     
       ///////////////options
        if($this->input->post('IsPost_save_options_maillist')=="y"){          
          $checkdata= $this->admin_model->setOptionsContactus();           
           if($checkdata==true){
             $data['optionsForm_update']=true;                
           }           
       }            
      $rows=$this->admin_model->getOptionsMaillist();
      $rows_options=$this->admin_model->getOptions();
      $data['contactus_rows']=$rows;
      $data['opt_rows']=$rows_options;
 }
 /////////////////////
 
 
 /*****************************/
  
  /////////////////////
 if($param=='emailoptions'){
     
     
       ///////////////options
        if($this->input->post('IsPost_save_options_maillistForm')=="y"){          
          $checkdata= $this->admin_model->setOptionsMasmail();           
           if($checkdata==true){
             $data['optionsForm_update2']=true;                
           }           
       }            
      $rows=$this->admin_model->getOptionsMaillist();
      
      $data['masmail_options_rows']=$rows;
      
 }
 /////////////////////
 
 
 
  if($param=='viewmsg'){
      
       if($this->input->post('IsPost_delete_msg_inbox')=="y"){    
      $this->admin_model->delete_message();
       }
       
          if($this->input->post('IsPost_replay_msg')=="y"){    
       $checkdata=$this->admin_model->replay_Email();
              
               if($checkdata==true){
             $data['replay_check']='send';                
           } else {
                $data['replay_check']='error'; 
               
           }
              
       }
      
      
      
       $result= $this->admin_model->getinfoInbox();
      
      
      $data['inbox_rows']=$result;
  }
 
 
 
 
 
 
 
 
 
 
 
 
 ///////////////////////
 
 
 if($param=='' || $param=='page'){
     
     
     
     
     if($this->input->post('IsPost_delinbox')=="y"){
             
             $this->admin_model->delete_Inbox();
             
         }
       
       
      
   $result= $this->admin_model->getInboxMessage();
     
   @$data['Rows_inbox']   =  $result['Rows_inbox'];
   $data['Total_inbox']  =  $result['Total_inbox'];
   @$data['Paging_inbox'] =  $result['Paging_inbox'];
   ///////////////////////////////
      
     
 }
 

 
 
 
 
 /***********************************/
 
 
 
   
      
      
        $this->layout->view(Cp::VIEWPATH.'masmail', $data);
      
  }




public function requestMaillist(){
    $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
    
     $data=array();
 if($this->input->post('IsPost_sendmaillist')=="y"){
     
        
    $this->load->model('admin_model');
    $total_rs= $this->admin_model->getNumEmail();
      $data['total_email']=$total_rs;
      $data['subject_email']=$this->input->post('subject2');
      $data['msg_email']=$this->input->post('msg2');
 $this->load->view(Cp::VIEWPATH.'requestmail', $data); 
 } 
 
 
   
     
}

///////////////////////////////
 public function notifcation(){
     $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
  $data=array();
   $this->load->model('admin_model');
   $this->Admin_model->set_notification_read();
    $result= $this->admin_model->getall_notification();
     
   $data['Rows_notifcation']   =  $result['Rows_notifcation'];
   $data['Total_notifcation']  =  $result['Total_notifcation'];
   $data['Paging_notifcation'] =  $result['Paging_notifcation'];
     
   
  $this->layout->view(Cp::VIEWPATH.'notifcation', $data);
 }







public function media(){
    $this->load->library('session');
//$api = $this -> load -> library('apiservices');
  //$api->CP_Auth(1,true,'No direct script access allowed');
 //$this->config->set_item('enable_query_strings', TRUE);
$data=array();


     $this->load->model('admin_model');
  // $data['options_media']= 
  
  if($this->input->post("indir")=="6"){
      
  $checkupload=$this->admin_model->UploadFiles();
  if($checkupload==false){
      $data['result_upload']='ERROR_Upload';
  } else {
      
    $data['result_upload']=  $checkupload;
   $this->session->set_userdata($checkupload);
  }
  
  
  }
     
  if($this->input->post('IsPost_media_options')=="y"){
           
          $checkdata= $this->admin_model->setOptions_Media();
           
           if($checkdata==true){
             $data['media_update']=true; 
               
           }
           
       }
     
 $rows=$this->admin_model->getOptions();
  $data['media_rows']=$rows;
  ///////////////end opetions/////////////    
 
   
   
 if($this->input->post("newfolder")=='y'){
$path=$this->input->post("Path");
$foldername=$this->input->post("foldername");
@mkdir($path.'/'.$foldername,0775);

}  
   
   
     if($this->input->post("indir")=="3"){
      $path=$this->input->post("Path");   
 $del=$this->input->post("del");
 $len=count($del);
        if(is_array($del)){
for($i=0;$i<$len;$i++){
if(is_dir($path.'/'.$del[$i])){
if($path.'/'.$del[$i]=='./assets/media'){
 continue;
} else {
$api->removeFolder($path.'/'.$del[$i]);
}

}
else {
@unlink($path.'/'.$del[$i]);
}

}  
        }    
         
         
     }
   
   
    //////////////
    
    
      if($this->input->post("indir")=="2"){
        $filedown= $this->load->library('Compress');
        $this->load->helper('download');
        
   $path=$this->input->post("Path");   
 $del=$this->input->post("del");
 $len=count($del);

 if(is_array($del) && $len!=0){
     $n_file=array();
     foreach ($del as $key => $val) {
         $n_file[]=$path.'/'.$val;
     }
         
       $name_rand=time().'.zip';   
       //echo implode($n_file, ',');
      $filedown->Zip('assets/tmp/'.$name_rand,implode($n_file, ',')); 
     // force_download($name_rand, file_get_contents('assets/tmp/'.$name_rand));
     $api->downloadFile('assets/tmp/'.$name_rand); 
     @unlink('./assets/tmp/'.$name_rand); 
     }
     //@unlink('./assets/tmp/'.$name_rand); 
 }
 
 
 
      
 
    /////////////////////////////
  ////////////////////////////////  
 // if($this->input->post("IsPost_sort")!=''){
      if($this->input->post("indir")=="5"){
          
    $val= $this->input->post("IsPost_sort");
      switch($val){
          case "1":
              $data['media_sort']=1;
              $data['media_sortasc']='SORT_ASC';
              break;
              case "2":
                   $data['media_sort']=2;
              $data['media_sortasc']='SORT_ASC';
              break;
                  case "4":
               $data['media_sort']=4;
              $data['media_sortasc']='SORT_ASC';
              break;
              default:
             $data['media_sort']=1;
              $data['media_sortasc']='SORT_ASC';
      }
      
  } else {
     $data['media_sort']=1;
     $data['media_sortasc']='SORT_ASC'; 
      
  }
  
  //////////////////////////////////   
    
  if($this->input->post("indir")=="1"){
    
$data['current_path']=$this->input->post("Path",true);
} else {
$data['current_path']="assets/media";
}  
    
    
    
    
$this->layout->view(Cp::VIEWPATH.'media', $data); 
}



////////////////////////////////////////////////////





public function Apimedia(){
 
//$api = $this -> load -> library('apiservices');
 // $api->CP_Auth(1,true,'No direct script access allowed');
$data=array();
//$this->config->set_item('enable_query_strings', TRUE);

     $this->load->model('admin_model');
  // $data['options_media']= 
  
  if($this->input->post("indir")=="6"){
  $checkupload=$this->admin_model->UploadFiles();
  if($checkupload==false){
      $data['result_upload']='ERROR_Upload';
  } else {
      
    $data['result_upload']=  $checkupload;
   $this->session->set_userdata($checkupload);
  }
  
  
  }
  
  if($this->input->post('IsPost_media_options')=="y"){
           
          $checkdata= $this->admin_model->setOptions_Media();
           
           if($checkdata==true){
             $data['media_update']=true; 
               
           }
           
       }
     
 $rows=$this->Admin_model->getOptions();
  $data['media_rows']=$rows;
  ///////////////end opetions/////////////    
 
   
   
 if($this->input->post("newfolder")=='y'){
$path=$this->input->post("Path");
$foldername=$this->input->post("foldername");
@mkdir($path.'/'.$foldername,0775);

}  
   
   
     if($this->input->post("indir")=="3"){
      $path=$this->input->post("Path");   
 $del=$this->input->post("del");
 $len=count($del);
        if(is_array($del)){
for($i=0;$i<$len;$i++){
if(is_dir($path.'/'.$del[$i])){
if($path.'/'.$del[$i]=='assets/media'){
 continue;
} else {
$api->removeFolder($path.'/'.$del[$i]);
}

}
else {
@unlink($path.'/'.$del[$i]);
}

}  
        }    
         
         
     }
   
   
    //////////////
    
    
      if($this->input->post("indir")=="2"){
        $filedown= $this->load->library('Compress');
        $this->load->helper('download');
        
   $path=$this->input->post("Path");   
 $del=$this->input->post("del");
 $len=count($del);

 if(is_array($del) && $len!=0){
     $n_file=array();
     foreach ($del as $key => $val) {
         $n_file[]=$path.'/'.$val;
     }
         
       $name_rand=time().'.zip';   
       //echo implode($n_file, ',');
      $filedown->Zip('assets/tmp/'.$name_rand,implode($n_file, ',')); 
     // force_download($name_rand, file_get_contents('assets/tmp/'.$name_rand));
     $api->downloadFile('assets/tmp/'.$name_rand); 
     @unlink('./assets/tmp/'.$name_rand); 
     }
     //@unlink('./assets/tmp/'.$name_rand); 
 }
 
 
 
      
 
    /////////////////////////////
  ////////////////////////////////  
 // if($this->input->post("IsPost_sort")!=''){
      if($this->input->post("indir")=="5"){
          
    $val= $this->input->post("IsPost_sort");
      switch($val){
          case "1":
              $data['media_sort']=1;
              $data['media_sortasc']='SORT_ASC';
              break;
              case "2":
                   $data['media_sort']=2;
              $data['media_sortasc']='SORT_ASC';
              break;
                  case "4":
               $data['media_sort']=4;
              $data['media_sortasc']='SORT_ASC';
              break;
              default:
             $data['media_sort']=1;
              $data['media_sortasc']='SORT_ASC';
      }
      
  } else {
     $data['media_sort']=1;
     $data['media_sortasc']='SORT_ASC'; 
      
  }
  
  //////////////////////////////////   
    
  if($this->input->post("indir")=="1"){
    
$data['current_path']=$this->input->post("Path",true);
} else {
$data['current_path']="assets/media";
}  
    
    
    
  $this->load->view(Cp::VIEWPATH.'apimedia', $data);  
//$this->layout->view(Cp::VIEWPATH.'media', $data); 
}




public function testmedia(){
    $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
  $data=array();
        
$this->layout->view(Cp::VIEWPATH.'testmedia', $data);   
}


//////////////////////////////////////////////////////////////


public function cat(){
    $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
  $data=array(); 
    $this->load->model('admin_model'); 
    $this->load->library('form_validation');
    $this->form_validation->CI = $this;

    $this->form_validation->set_error_delimiters('<div class="uk-alert uk-alert-danger font_deafult dirTemplate">', '</div>');
    
      if($this->input->post("IsPost_delcat")=="y"){
                $this->admin_model->DeleteCat();
          
      }
    
    
    
    if($this->input->post("IsPost_addcat")=="y"){
           $this->form_validation->set_rules('name1',$this->lang->line('cat_noName'),'required');
            if ($this->form_validation->run() != FALSE){
       $result= $this->admin_model->setNewCat();
        if($result==true){
            $data['result_cat']='add';
        } 
         if($result==false){
            $data['result_cat']='error';
        } 
         
            }
        
    }
    
    
   //////////edit//////////////////////////
   
    if($this->input->post("IsPost_editcat")=="y"){
        
      $this->form_validation->set_rules('name1',$this->lang->line('cat_noName'),'required');
            if ($this->form_validation->run() != FALSE){   
    $result= $this->admin_model->setEditCat();
        if($result==true){
            $data['result_cat']='add';
        } 
         if($result==false){
            $data['result_cat']='error';
        } 
   
    }
    }
   
   
    $seg = $this -> uri -> segment(3);
    $total_seq= $this->uri->total_segments();
    if($total_seq==4){
        
        if($this -> uri -> segment(3)=='edit'){
            if(ctype_digit($this -> uri -> segment(4))){
                //
                $data['cat_edit']='edit';
                $data['cat_id']=$this -> uri -> segment(4);
                $cat_row = $this->Admin_model->get_cat($this -> uri -> segment(4));
              
                $data['cat_row']=$cat_row;
                $data['select_cat2'] =@$this->Admin_model->MainCatSelect1('uk-form-width-large font_deafult',$cat_row['ID'],0);
            
                
            }
        }
        
    }
     
    
    
    
    
    
    
    
  $rcat=$this->admin_model->getCat();
 
 
 $data['select_cat']=@$this->admin_model->MainCatSelect1('uk-form-width-large font_deafult',0,0);
  $data['cat_list']=@$rcat['Rows_cat'];
 // $data['Paging_cat']=$rcat['Paging_cat'];
 $this->layout->view(Cp::VIEWPATH.'cat', $data);    
}










public function memebers(){
    $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
 $data=array();
    
    //load default lib
    $api = $this->load->library('apiservices');
    $this->load->model('admin_model'); 
    $this->load->library('form_validation');
    $this->form_validation->CI = $this;
    
    
    
$seg = $this -> uri -> segment(3);

 $data['mem_country']= $this->admin_model->getCountry();
switch($seg) {
        
      case "new":
        //  echo 'new user';
 $this->form_validation->set_error_delimiters('<div class="uk-alert uk-alert-danger font_deafult dirTemplate">', '</div>');
                
  if($this->input->post("IsPost_adduser")=="y"){
      $this->form_validation->set_rules('fullname',$this->lang->line('mem_missing_name'),'required'); 
       $this->form_validation->set_rules('email',$this->lang->line('mem_missing_email'),'required|valid_email');
        //$this->form_validation->set_rules('username',$this->lang->line('mem_missing_username'),'required');
       $this->form_validation->set_rules('password',$this->lang->line('mem_missing_password'),'required');
       
       
         if ($this->form_validation->run() != FALSE){
             
             $result_add=$this->admin_model->setNewMembers();
          
          if( $result_add==true){
              $data['result_newuser']='OK';
          }
          
            if( $result_add==false){
              $data['result_newuser']='ERROR';
          }
             
         }
       
       
       
      
      
  }      
        
        
        
        
        
        
        
        
        
        
       
   
        
        
        
          break;
          
        case "edit":
         // echo 'edit user';
         $this->form_validation->set_error_delimiters('<div class="uk-alert uk-alert-danger font_deafult dirTemplate">', '</div>');
      
        if($this->input->post("IsPost_edituser")=="y"){
       $this->form_validation->set_rules('fullname',$this->lang->line('mem_missing_name'),'required'); 
       $this->form_validation->set_rules('email',$this->lang->line('mem_missing_email'),'required|valid_email');
       $this->form_validation->set_rules('password',$this->lang->line('mem_missing_password'),'required');
       
          if ($this->form_validation->run() != FALSE){
              
         $result_update=$this->admin_model->setUpdateMembers();
              
           
          if( $result_update=='update'){
              $data['result_edituser']='Edit';
          }
          
            if( $result_update=='found'){
              $data['result_edituser']='Error_edit';
          }
          }  
       
       
        
        }
        
         
         
         
       $data['memeber_info']= $this->admin_model->get_User(); 
         
         
         
         
         
         
         
         
          break;    
          
          
        case "options":
         // echo 'options user';
     
     
       if($this->input->post("IsPost_updatememberOptions")=="y"){
     
     $checkdata=$this->admin_model->setOptions_members();
     
         if($checkdata==true){
             $data['members_options']=true; 
               
           }
     
     
       }
         
  $rows=$this->admin_model->getOptions();
  $data['memeber_options']=$rows;
         
         
         
          break;    
          
          
      default:  
          //echo 'list';
  //  
    
    
    
    
    
    
    
    
    
  
    
    if($this->input->post("IsPost_delmembers")=="y"){
              
         $this->admin_model->DeleteMembers();      
              
     }
    
    if($this->input->post("IsPost_activemembers")=="y"){
              
         $this->admin_model->setActiveMembers();      
              
     }
    
      if($this->input->post("IsPost_deactivemembers")=="y"){
              
         $this->admin_model->setDeActiveMembers();      
              
     }
    
    
       
          
   $result= $this->admin_model->getMembers();
    // var_dump($result);
   $data['Rows_memebers']   =  $result['Rows_memebers'];
   $data['Total_memebers']  =  $result['Total_memebers'];
   $data['Paging_memebers'] =  $result['Paging_memebers'];
          
          
          
          
          
  }







    
    
$this->layout->view(Cp::VIEWPATH.'members', $data);   
}



















/////////////////ajax work/////////////////////////////

public function responseMaillist(){
    $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
     $this->load->model('admin_model');
    $num= $this->admin_model->dosend_email($this->input->get('title'),$this->input->get('message'));
   echo $num;
     

}




public function getnew_message(){
    
    $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
    
     $this->load->model('admin_model');
    $rs=$this->admin_model->get_new_messgae();
    
    if(is_array($rs['row'])){
        $i=0;
        foreach($rs['row'] as $rows){
            $titles='...'. mb_substr($rows['message'], 0,50);
            $links=base_url('cp/masmail/viewmsg/'.$rows['ID']);
            $i++;
           echo "<li><a href=$links>$titles</a></li>" ;
            if($i==10){
                echo "<li><a href='".base_url('cp/masmail')."'>". $this->lang->line('masmail_msg_list_more')."</a></li>" ;
                break;
            }
            
        }
    } else {
        
        echo $this->lang->line('masmail_msg_list_empty');
    }
    
}


public function getCount_message(){
    $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
     $this->load->model('admin_model');
    $rs=$this->admin_model->get_new_messgae();
    echo $rs['len'];
    
    
}




public function get_notifcation(){
    $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
     $this->load->model('admin_model');
     $rs=$this->admin_model->get_notifcation_num();
    echo $rs;
    //  $this->admin_model->set_notification_read();
   
}


public function get_new_notify(){
   $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
       $this->load->model('admin_model');
    $rs=$this->admin_model->get_new_notifcation();
     
    if(is_array($rs)){
        $i=0;
        foreach($rs as $rows){
            $titles='...'. mb_substr($rows['message'], 0,90);
             $links=$rows['links'];
            $i++;
           echo "<li><a href=$links>$titles</a></li>" ;
            if($i==10){
                echo "<li><a href='".base_url('cp/notifcation')."'>". $this->lang->line('masmail_msg_list_more')."</a></li>" ;
                break;
            }
            
        }
    } else {
        
        echo $this->lang->line('masmail_msg_list_empty');
    }
    
    
}



 public function update_notify(){
   $api = $this -> load -> library('apiservices');
  $api->CP_Auth(1,true,'No direct script access allowed');
     $this->load->model('admin_model');
      
  
     $this->admin_model->set_notification_read();
 }
 

 
 
 
 public function do_upload()
    {
 // $api = $this -> load -> library('apiservices');
 //$api->CP_Auth(1,true,'No direct script access allowed');
//$this->config->set_item('enable_query_strings', TRUE);

  $query = $this -> db -> get('tmpos');
        $row = $query -> row_array();  
         $da= array('File_name'=> $row['File_name'],
         'File_GD'=>$row['File_GD']); 
     
   echo  json_encode($da,true);


    }
 
 
 
 
 
 
 
 
 public function ajaxaupload(){
     $data=array();
     
      if($this->input->post("indir")=="6"){
      
  $checkupload=$this->admin_model->UploadFiles();
  if($checkupload==false){
      $data['result_upload_ajax']='ERROR_Upload';
  } else {
      
    $data['result_upload_ajax']=  $checkupload;
   $this->session->set_userdata($checkupload);
  }
  
  
  }
     
     
  $this->load->view(Cp::VIEWPATH.'ajaxaupload',$data);   
 }
 
 
 
 
 
 
 
 
 
 




}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */