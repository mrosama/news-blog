<?php
$lang['ads_new'] = "  New Ads ";
$lang['ads_edit'] = " Edit Ads";
$lang['ads_list'] = "Ads";
$lang['ads_name'] = "Ads Name  ";
$lang['ads_link'] = "Ads Link";
$lang['ads_code'] = " Custom Code    ";
$lang['ads_width'] = "View Ads";
$lang['ads_height'] = "Height ";
$lang['ads_file'] = " Ads File";
$lang['ads_save'] = " Save";
$lang['ads_winow'] = " Link Target";
$lang['ads_inwindow'] = " In Self Window";
$lang['ads_newwindow'] = " In New Window    ";
$lang['ads_photo'] = " Ads";
$lang['ads_ID'] = " ID";
$lang['ads_preview'] = " Preview";
$lang['ads_mis_name'] = " Name is Missing    ";
$lang['ads_mis_codefile'] = " Enter Ads File Or Code ";
$lang['ads_msg_error'] ="Name already exists";
$lang['ads_msg_add'] =" Data has been saved successfully"; 
$lang['ads_delete']=" Delete ";
?>