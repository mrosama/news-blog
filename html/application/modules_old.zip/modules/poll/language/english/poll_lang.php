<?php
$lang['poll_list'] = " Polls";
$lang['poll_new'] = "  New Poll";
$lang['poll_edit'] = "  Edit ";
$lang['poll_question1'] = "  Question ";
$lang['poll_question2'] = "  Question -Englsih ";
$lang['poll_status'] = "  Status ";
$lang['poll_delete'] = "  Delete  ";
$lang['poll_save'] = "  Save  ";
$lang['poll_option'] = "  Option ";
$lang['poll_option2'] = " Option - Englsih    ";
$lang['poll_status_active'] = "  Enabled ";
$lang['poll_status_dactive'] = " Disabled ";
$lang['poll_message_add'] = "   Data has been saved successfully  ";
$lang['poll_message_found'] = "  Question already registered  ";
$lang['poll_ID'] = "  ID  ";
$lang['poll_mis_question'] = "   Question missing   ";

////////////////////
$lang['poll_site_send']="Vote";
$lang['poll_site_view']="Results ";
$lang['poll_site_msg1']="Please select an answer from Poll";
?>