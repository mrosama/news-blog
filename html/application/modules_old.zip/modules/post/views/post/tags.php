<style type="text/css">

.tagcloud {
    clear:both;
    position:relative;
    font-size: 19px;
    text-align: center;
    padding: 15px;
    border: 1px solid #eeeeee;
    background-color: #f2f2f2;
    
    
   
}
</style>
<div class="tagcloud" style="max-width:450px;     word-wrap:break-word;">
    <?php
    echo @$mytag;
    ?>

</div>
