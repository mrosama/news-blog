<?php
$lang['media_norow'] ="  نأسف لا توجد فيديوهات مسجلة";
$lang['media_comments'] ="  التعليقات ";
$lang['media_misname']="ألاسم مفقود";
$lang['media_misemail']="البريد الالكتروني مفقود او غير صحيح";
$lang['media_send']="إرسال";
$lang['media_name']="الاسم";
$lang['media_email']="البريد الالكتروني";
$lang['media_msg']="التعليق";
$lang['media_errorcode']="كود التحقق غير صحيح";
$lang['media_addcomments']="تم إضافة التعليق سوف يتم نشرة بعد مراجعة الادارة ";
$lang['media_comment_link']=" تم إضافة تعليق علي الفيديو";
$lang['media_comnum']="رد";
$lang['media_show'] ="مشاهدة";
$lang['media_time'] ="مشاهدة";
$lang['media_code'] =" كود التحقق";

?>