<?php
$lang['key_1'] = "1انا بكلم عربي";

$lang['contactus_title'] ="إتصل بنا";
$lang['contactus_name'] ="ألاسم";
$lang['contactus_email'] ="البريد الالكتروني";
$lang['contactus_site'] ="الموقع الالكتروني";
$lang['contactus_msg'] ="الرسالة";
$lang['contactus_btn_send'] ="إرسال";
$lang['contactus_captcha'] ="كود التحقق";
$lang['contactus_messgae_send'] ="تم إرسال الرسالة .سوف يتم الرد عليك في اقرب وقت";
$lang['contactus_message_fail'] ="فشل في إرسال الرسالة..من فضلك حاول مرة اخري في وقت لاحق";
$lang['contactus_input_name']="ألاسم مفقود";
$lang['contactus_input_email']="البريد مفقود او غير صالح";
$lang['contactus_input_msg']="الرسالة مفقودة";
$lang['contactus_input_captcha']="من فضلك أدخل كود التحقق";
$lang['contactus_input_required']="مطلوب";


$lang['maillinglist_titles']="القائمة البريدية";
$lang['maillinglist_subcribe']="إشتراك";
$lang['maillinglist_unsubcribe']="إلغاء الاشتراك";
$lang['maillinglist_btnsubcribe']="إرسال";
$lang['maillinglist_add_sucess']="تم إضافة البريد الالكتروني إلي القائمة البريدية";
$lang['maillinglist_add_fail']="البريد";
$lang['maillinglist_remove_subcribe']="إلغاء الاشتراك";
$lang['maillinglist_remove_msg1']="تم إرسال رسالة بريدية لتاكيد حذف البريد";
$lang['maillinglist_remove_msg2']="البريد الالكتروني مسجل من قبل";
$lang['maillinglist_remove_msg3']="الرابط غير صحيح..من فضلك تأكد من الرابط المطلوب";
$lang['maillinglist_remove_msg4']="تم حذف البريد الاكتروني";
$lang['maillinglist_remove_msg5']="البريد الالكتروني غير مسجل لدينا";
$lang['maillinglist_add_msg5']="تم إضافة بريد إلي القائمة البريدية";
$lang['maillinglist_subject_email']='باعت بريد -تأكيد حذف البريد من القائمة البريدية';
$lang['maillinglist_msg_email']='أضغط علي الرابط لتفعيل حذف البريد..';
$lang['maillinglist_msg_empty']='';

$lang['member_login_username']='البريد الالكتروني';
$lang['member_login_password']='كلمة المرور';
$lang['member_login_btn']='دخول';
$lang['member_login_Errormsg']='خطأ في تسجيل الدخول';
$lang['member_email']='البريد الالكتروني';
$lang['member_country']='الدولة';
$lang['member_regLink']='مستخدم جديد';
$lang['member_forgetpass']='إستعادة كلمة المرور';
$lang['member_gender']='الجنس';
$lang['member_gender_male']='ذكر';
$lang['member_gender_female']='أنثي';
$lang['member_pic']='الصورة الرمزية';
$lang['member_password']='كلمة المرور';
$lang['member_cpassword']='تأكيد كلمة المرور';
$lang['member_addnew']='تسجيل البيانات';
$lang['member_profile']='الملف الشخصي';
$lang['member_logout']='تسجيل خروج';
$lang['member_profiles']='تسجيل خروج';
$lang['member_msg_welcome']="/ مرحبا ";
$lang['mem_name']="ألاسم";
$lang['mem_password']="كلمة المرور";
$lang['mem_cpassword']="تأكيد كلمة المرور";
$lang['mem_country']="الدولة";
$lang['mem_gender_male']="ذكر";
$lang['mem_gender_female']="أنثي";

$lang['mem_nofication']="تم إضافة عضوية جديدة";
$lang['mem_missing_name']='الاسم مفقود';
$lang['mem_missing_email']='البريد الالكتروني مفقود او غير صالح';
$lang['mem_missing_username']='اسم المستخدم مفقود';
$lang['mem_missing_password']='كلمة المرور مفقودة';
$lang['mem_missing_cpassword']=' كلمة المرور لا تساوي تأكيد كلمة المرور';
$lang['mem_msg_add']="تم إضافة بيانات العضو بنجاح";
$lang['mem_msg_error']="فشل في إضافة البيانات  او البريد   مسجل من قبل";
$lang['mem_msg_errorpic']="نوع الصورة غير مسموح بها";
$lang['mem_email_msg']="تفعيل ألاشتراك في الموقع";
$lang['mem_email_links']="أنسخ الرابط في المتصفح لتفعيل حسابك";

$lang['mem_activebyadmin']= "تم تسجيل بيانات العضوية بنجاح .سوف يتم تفعيل حسابك بعد مراجعة إدارة الموقع";
$lang['mem_activebyemail']= " تم تسجيل بيانات العضوية بنجاح..تم إرسال رسالة إلي بريدك لتفعيل حسابك علي الموقع";
$lang['mem_activeok']="تم تفعيل إشتراكك في الموقع بنجاح";
$lang['mem_restorepass1']="من فضلك أدخل بريدك الالكتروني ";
$lang['mem_restorepass3']="إرسال";
$lang['mem_restoresubject']="باعت بريد -تأكيد إستعادة كلمة المرور";
$lang['mem_restoremsg1']="أضغط علي الرابط لتفعيل كلمة المرور الجديدة  ..أو تجاهل هذة الرسالة في حالة عدم رغبتك في تغير كلمة المرور";
$lang['mem_restoremsg2']="كلمة المرور الجديدة";
$lang['mem_restoremsgok']=" تم إرسال رابط تفعيل كلمة المرور الجديدة إلي بريدك..افحص بريدك  لتاكيد كلمة المرور";
$lang['mem_changepassok']=" تم تغير كلمة المرور بنجاح";
$lang['mem_updateAccount']=" تم حفظ البيانات بنجاح";
?>