<?php
$lang['posts_tag'] ="  Tags";
$lang['posts_addTags'] =" New Tag";
$lang['posts_add'] ="  Article -News";
$lang['posts_edit'] =" Edit";
$lang['posts_comments'] =" Comments";
$lang['posts_save'] =" Save";
$lang['posts_msgadd'] ="Data has been saved successfully";
$lang['posts_msgerror'] =" Data Inserted Before ";
$lang['posts_ID'] =" ID";
$lang['posts_title'] ="Article -News";
$lang['posts_delete'] =" Delete";
$lang['posts_cat'] ="Section";
$lang['posts_btn_search'] ="  Search ";
$lang['posts_btn_add'] =" Date";
$lang['posts_date'] ="  Date";
$lang['posts_search_msg'] ="   Sorry for No  results";
$lang['posts_tagsname']="  Tag Name";
$lang['posts_error2']="Please choose a section";
$lang['posts_name']="Article Title";
$lang['posts_name_en']="Title article - second language ";
$lang['posts_pic']="  Upload Image";
$lang['posts_picsmall']="  Thumbnail ";
$lang['posts_picstitle']="  Comment on the image ";
$lang['posts_tagsname_missing']="Name tag missing";
$lang['posts_author']="Writer";
$lang['posts_content']=" Content";
$lang['posts_content_en']="Content - second language";
$lang['posts_validate_title']="Title of the article is missing";
$lang['posts_validate_pic']="Image type is not allowed";
$lang['posts_validate_authur']="  The author's name is missing  ";
$lang['posts_back']="  Back";
$lang['posts_validate_cat']="Section missing";
$lang['posts_comment_name']=" Name";
$lang['posts_comment_email']="  Email  ";
$lang['posts_comment_status']="Status";
$lang['posts_comment_enable']="Enabled";
$lang['posts_comment_disabled']="disabled";
$lang['posts_comment_content']=" Content";
$lang['posts_comment_active']="Enabled";
$lang['posts_comment_deactive']="  Disabled";
$lang['posts_hint']="  Separate tags with commas ";
$lang['posts_choosetag']="Choose from the most used tags";
$lang['posts_fullscreen']="Showing editor full list of shortcut display full screen";
$lang['posts_addtags']="  Add ";
?>