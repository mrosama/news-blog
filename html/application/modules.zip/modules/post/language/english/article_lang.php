<?php
$lang['article_norow'] =" Sorry, there are no articles registered";
$lang['article_comments'] ="  Comments ";
$lang['article_misname']="First Name is missing";
$lang['article_misemail']="E-mail is missing or incorrectly  ";
$lang['article_send']="Send ";
$lang['article_name']="Name";
$lang['article_email']="E-mail";
$lang['article_msg']="Comment";
$lang['article_errorcode']=" Captcha is incorrect " ;
$lang['article_addcomments']=" Added comment will be published after a review of the administration";
$lang['article_comment_link']=" Added comment on articles";
$lang['article_comnum']=" reply";
$lang['article_show'] =" View ";
$lang['article_time'] ="View";
$lang['article_code'] =" Captcha";
$lang['article_title'] ="   Articles - News ";
$lang['article_searchrs'] ="    Search Result   ";