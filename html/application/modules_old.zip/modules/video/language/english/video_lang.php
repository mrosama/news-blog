<?php
$lang['video_add'] ="New Video";
$lang['video_edit'] =" Edit";
$lang['video_comments'] ="Comments ";
$lang['video_save'] ="Save ";
$lang['video_msgadd'] ="Data has been saved successfully ";
$lang['video_msgerror'] ="";
$lang['video_ID'] =" ID";
$lang['video_title'] ="Videos ";
$lang['video_delete'] ="Delete";
$lang['video_cat'] ="Section";
$lang['video_search'] ="Search on YouTube ";
$lang['video_btn_search'] ="  Search ";
$lang['video_btn_add'] =" Date";
$lang['video_serach_title'] ="   Search on YouTube ";
$lang['video_date'] ="  Date";
$lang['video_search_msg'] =" Sorry  No results";
$lang['video_movetovideo']="  Transfer to Videos";
$lang['video_error1']="Please select from the list of videos";
$lang['video_error2']="Please choose a section";
$lang['video_name']="  Video title";
$lang['video_name_en']="Video title - second language";
$lang['video_filename']=" Upload Video";
$lang['video_pic']=" Upload a photo";
$lang['video_youtube']="YouTube link";
$lang['video_youtube_msg']="Will be the inclusion of the title and the image file automatically YouTube ";
$lang['video_author']="Writer";
$lang['video_content']="Content";
$lang['video_content_en']="Content - Second Language";
$lang['video_validate_title']="Video title Missing";
$lang['video_validate_pic']="Image type is not allowed";
$lang['video_validate_authur']="The author's name is missing";
$lang['video_validate_file1']="Chose the video file or enter the file link YouTube";
$lang['video_validate_youtubepic']="You can not choose a photo .. inclusion of the image will be automatically YouTube";
$lang['video_validate_cat']="  Section missing";
$lang['video_tip']="Will be the inclusion of the title and the image file automatically YouTube";
$lang['video_comment_name']="Name";
$lang['video_comment_email']="Email  ";
$lang['video_comment_status']="Status";
$lang['video_comment_enable']="Activating";
$lang['video_comment_disabled']="Deactivating  ";
$lang['video_comment_content']="Content";
$lang['video_comment_active']="Activating";
$lang['video_comment_deactive']="Deactivating";



?>