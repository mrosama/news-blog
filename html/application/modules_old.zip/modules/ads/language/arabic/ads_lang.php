<?php
$lang['ads_new'] = " إعلان جديد";
$lang['ads_edit'] = " تعديل ألاعلان  ";
$lang['ads_list'] = "ألاعلانات";
$lang['ads_name'] = "أسم ألاعلان";
$lang['ads_link'] = "رابط ألاعلان";
$lang['ads_code'] = " كود إعلاني مخصص";
$lang['ads_width'] = "عرض ألاعلان";
$lang['ads_height'] = "طول ألاعلان";
$lang['ads_file'] = " تحميل ملف ألاعلان";
$lang['ads_save'] = "حفظ";
$lang['ads_winow'] = "فتح رابط ألاعلان";
$lang['ads_inwindow'] = "في نفس النافذة";
$lang['ads_newwindow'] = "في نافذة مستقلة";
$lang['ads_photo'] = "ألاعلان";
$lang['ads_ID'] = "رقم ألاعلان";
$lang['ads_preview'] = "معاينة";
$lang['ads_mis_name'] = "أسم ألاعلان مفقود";
$lang['ads_mis_codefile'] = "أدخل ملف ألاعلان او كود ألاعلان";
$lang['ads_msg_error'] ="أسم ألاعلان مسجل من قبل";
$lang['ads_msg_add'] =" تم حفظ البيانات بنجاح"; 
$lang['ads_delete']="حذف ";
?>