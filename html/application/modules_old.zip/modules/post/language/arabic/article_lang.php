<?php
$lang['article_norow'] ="  نأسف لا توجد مقالات مسجلة";
$lang['article_comments'] ="  التعليقات ";
$lang['article_misname']="ألاسم مفقود";
$lang['article_misemail']="البريد الالكتروني مفقود او غير صحيح";
$lang['article_send']="إرسال";
$lang['article_name']="الاسم";
$lang['article_email']="البريد الالكتروني";
$lang['article_msg']="التعليق";
$lang['article_errorcode']="كود التحقق غير صحيح";
$lang['article_addcomments']="تم إضافة التعليق سوف يتم نشرة بعد مراجعة الادارة ";
$lang['article_comment_link']=" تم إضافة تعليق علي المقالات";
$lang['article_comnum']="رد";
$lang['article_show'] ="مشاهدة";
$lang['article_time'] ="مشاهدة";
$lang['article_code'] =" كود التحقق";
$lang['article_title'] ="   المقالات -ألاخبار ";
$lang['article_searchrs'] ="    نتائج البحث ";
?>