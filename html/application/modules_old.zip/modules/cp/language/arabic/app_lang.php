<?php
$lang['app_welcome'] = " : مرحبا";
$lang['app_modules'] = "الموديلات -ألاضافات";
$lang['app_language'] = "اللــــــــــغات";
$lang['app_signout'] = "تسجيل الخروج";
$lang['app_home'] = "رئيسية الموقع";
$lang['app_chart'] = "إحصائيات الموقع";
$lang['app_options'] = "إعدادات";
$lang['app_memebers'] = "إدارة الاعضاء والمشرفين";
$lang['app_filesys'] = "إدارة الملفات والمجلدات";
$lang['app_msmail'] = "البريد والمراسلات";
$lang['app_vistors'] = "الزوار";
$lang['app_backup'] = "النسخ الاحتياطي";
$lang['app_help'] = "مساعدة";
$lang['app_mailbox'] = "صندوق الرسائل";
$lang['app_notify'] = "إشعارات";
$lang['app_colorA'] = "ألافتراضي";
$lang['app_colorB'] = "أسود";
$lang['app_colorC'] = "برتقالي";


$lang['options_message']="تم تحديث البيانات"; 
$lang['options_title']="إعدادات الموقع"; 
$lang['options_web_cache']="استخدام الكاش"; 
$lang['options_web_cache_time']="وقت الكاش بالدقائق"; 
$lang['options_notification_time']="ألاشعارات المقروءة متاحة   بالايام لمدة"; 
$lang['options_web_title']="إسم الموقع"; 
$lang['options_capacity']="المساحة الافتراضية للموقع -للاحصائيات"; 
$lang['options_web_status']=" إغلاق الموقع"; 
$lang['options_web_status_message']="رسالة إغلاق الموقع"; 
$lang['options_title_metadata']=" البيانات الوصفية"; 
$lang['options_title_socialnetwork']="الشبكات ألاجتماعية"; 
$lang['options_title_email']="  إعدادات خادم البريد"; 
$lang['options_mail_server']="خادم البريد الالكتروني"; 
$lang['options_email_received']="البريد الالكتروني -إستقبال الرسائل"; 
$lang['options_mail_sendmail']=" مسار SendMail"; 
$lang['options_mail_sender']="أسم الراسل ";
$lang['options_mail_smtp']="( SMTP ) خادم "; 
$lang['options_mail_user']="( SMTP ) مستخدم"; 
$lang['options_mail_pwd']="( SMTP ) كلمة المرور"; 
$lang['options_mail_port']="SMTP -  المنفذ";

$lang['options_encryption']="نظام التشفير"; 
$lang['options_encryptionselect1']="لا يوجد تشفير"; 
$lang['options_mail_format']="تنسيق الرسائل"; 
$lang['options_sendbutton']="حفظ البيانات"; 



$lang['backup_title']="نسخ احتياطي لقاعدة البيانات";
$lang['backup_select']="اختر نوع ملف قاعدة البيانات";
$lang['backup_select2']=" البريد الالكتروني ";
$lang['backup_btn1']="تحميل نسخة قاعدة البيانات";
$lang['backup_btn2']="إرسال إلي البريد الالكتروني";
$lang['backup_btn3']="إرسال";
$lang['backup_msgok']="تم إرسال نسخة من قاعدة البيانات إلي البريد الالكتروني";
$lang['backup_msgerror']="فشل في إرسال البريد الالكتروني";


$lang['visitor_title']='زوار الموقع';
$lang['visitor_counter_title']='إعدادات زوار الموقع';
$lang['visitor_select_title']='-- ألانتقال إلي --';
$lang['visitor_id']='مسلسل';
$lang['visitor_os']='نظام التشغيل';
$lang['visitor_browser']='المستعرض';
$lang['visitor_mobile']='موبايل';
$lang['visitor_country']='الدولة';
$lang['visitor_status']='حالة الاتصال';
$lang['visitor_date']='تاريخ الزيارة';
 


 
$lang['visitors_options_selectcounter']=" اختار عداد الزوار ";
$lang['visitors_options_selectcustom']="  كود مخصص  ";
$lang['visitors_options_entercode']=" أدخل الكود هنا ";
$lang['visitors_options_tempavalible']=" القوالب المتاحة";
$lang['visitors_options_counternumber']="عداد الزوار الحالي ";
$lang['visitors_options_discover']=" مستكشف دول الزوار";
$lang['visitors_options_vistortmp']=" قالب المتواجدون الان";
$lang['visitors_options_default']=" عداد الزوار ";
$lang['visitors_options_online']="  إعدادات المتواجدون الان  ";
$lang['visitors_options_selectmp1']=" القالب الافتراضي ";
$lang['visitors_options_selectmp2']="(Enter Code)   كود مخصص ";
$lang['visitors_options_discover1']=" قاعدة البيانات المحلية ";
$lang['visitors_options_discover2']=" خدمات الانترنت ";
 




$lang['masmail_inbox']="الرسائل الواردة";
$lang['masmail_sendmail']="إرسال بريد الالكتروني";
$lang['masmail_maillist']="القائمة البريدية";
$lang['masmail_sendmaillist']="مراسلة القائمة البريدية";
$lang['masmail_countactus']="إتصل بنا";
$lang['masmail_options']="إعدادات البريد والمراسلات";

$lang['masmail_sendmail_to']="عنوان البريد الالكتروني المرسل إلية";
$lang['masmail_sendmail_subject']="عنوان الرسالة";
$lang['masmail_sendmail_message']="محتوي الرسالة";
$lang['masmail_sendmail_attach']="ملحقات";
$lang['masmail_sendmail_btn']="إرسال البريد الالكتروني";
$lang['masmail_sendmail_messageok']="تم إرسال البريد بنجاح";
$lang['masmail_sendmail_messageerror']="فشل في إرسال البريد.حاول الارسال لاحقا.";

$lang['masmail_sendmail_errorTo']="البريد الالكتروني مفقود او غير صحيح";
$lang['masmail_sendmail_errorSubject']="عنوان الرسالة مفقودة او اكبر من مساحة الحقل";  
$lang['masmail_sendmail_errorMsg']="رسالة البريد مفقودة  "; 

$lang['masmail_maillist_title1']="إضافة البريد الاكتروني إلي القائمة البريدية  "; 

$lang['masmail_maillist_email']="البريد الالكتروني"; 
$lang['masmail_maillist_btn1']="حفظ البيانات"; 
$lang['masmail_maillist_titlep']=" بيانات القائمة البريدية";
$lang['masmail_maillist_sendmail']=" إرسال رسالة";  
$lang['masmail_maillist_datemsg']="تاريخ الاضافة";

$lang['masmail_maillist_delemail']="  حذف البريد الالكتروني  ";
$lang['masmail_maillist_erroraddmaillist']="  البريد الالكتروني غير صحيح او مسجل من قبل  ";

$lang['masmail_maillist_addmailok']="تم إضافة البريد الالكتروني إلي القائمة البريدية";
$lang['masmail_maillist_addmailerror']="فشل في إضافة البريد الالكتروني";

$lang['masmail_maillist_backtomaillist']="عودة إلي القائمة البريدية";

$lang['masmail_maillist_btn_send']="  إبداء الارسال";

$lang['masmail_maillist_btn_chartsend']="إحصائيات الارسال";

$lang['masmail_maillist_num_msg']="عدد الرسائل";
$lang['masmail_maillist_num_send']="  تم إرسال ";
$lang['masmail_maillist_status_send']=" حالة الاتصال";
$lang['masmail_maillist_status_on']=" متصل وجاري الارسال  ";
$lang['masmail_maillist_status_off']="  غير متصل الارسال متوقف";

$lang['masmail_maillist_on']="إستكمال";
$lang['masmail_maillist_off']="إيقاف";
$lang['masmail_maillist_cancel']="إلغاء الامر";


$lang['masmail_options_incomeemail']=" البريد الالكتروني للاستقبال الرسائل";
$lang['masmail_options_allow_notifications']="تفعيل إشعارات البريد الالكتروني";
$lang['masmail_options_allow_formcountactus']="إستخدام نموذج ألاتصال";
$lang['masmail_options_allow_infobox']="إستخدام بيانات ألاتصال";
$lang['masmail_options_allow_infobox_title']="بيانات ألاتصال";
$lang['masmail_options_order_box_up']="بيانات ألاتصال أعلي النوذج";
$lang['masmail_options_order_box_down']="بيانات الاتصال أسفل النوذج";

$lang['masmail_options_maillist_allowform']="إستخدام نموذج القائمة البريدية";
$lang['masmail_options_maillist_allowcode']="إستخدام نموذج مخصص";
$lang['masmail_options_maillist_codedata']="كود النوذج المخصص";
$lang['masmail_options_maillist_notifications']="تفعيل إشعارات البريد الالكتروني ";
$lang['masmail_options_maillist_deletelinks']="حذف البريد الالكتروني من خلال رابط تفعيل";

$lang['masmail_viewmsg']="عرض الرسالة";
$lang['masmail_delete']=" حذف   ";


$lang['masmail_msg_name']="ألاسم";
$lang['masmail_msg_email']="البريد الالكتروني";
$lang['masmail_msg_site']="الموقع";
$lang['masmail_msg_content']="الرسالة";
$lang['masmail_msg_replay']="رد علي الرسالة";
$lang['masmail_msg_title']="عنوان الرسالة";
$lang['masmail_msg_content_replay']="الرسالة";
$lang['masmail_msg_send']="إرسال";
$lang['masmail_msg_clear']="مسح";
$lang['masmail_msg_back']="عودة";
$lang['masmail_msg_delete']="حذف الرسالة";

$lang['masmail_msg_list_more']=" المزيد";
$lang['masmail_msg_list_empty']=" لا توجد رسائل جديدة";


$lang['media_title']="إدارة الملفات والمجلدات";
$lang['media_options']="إعدادات الملفات والمجلدات";
$lang['media_file_type']="أمتدادات الملفات المسموح بها";
$lang['media_upload_options']="تحميل الملفات";
$lang['media_upload_options_type1']="قياسي";
$lang['media_upload_options_type2']="Ajax";
$lang['media_upload_thumbnail_title']="إعدادات الصور";
$lang['media_upload_thumbnail']="تصغير الصور";
$lang['media_upload_thumbnail_handel']="   معالجة الصور المصغرة   ";
$lang['media_upload_thumbnail_orginal']="تصغير الصورة المرفوعة";
$lang['media_upload_thumbnail_copy']="نسخة مستنسخة من الصورة الاصلية";
$lang['media_upload_thumbnail_width']="العرض";
$lang['media_upload_thumbnail_height']="الطول";
$lang['media_upload_filename_options']="اسماء الملفات المرفوعة";
$lang['media_upload_filename_byauto']="دون تغير";
$lang['media_upload_filename_bytime']=" تغير تلقائي";

$lang['media_upload_newdir']="مجلد جديد";
$lang['media_upload_updir']="  مستوي أعلي ";
$lang['media_upload_deldir']=" حذف الملفات المختارة ";
$lang['media_upload_downdir']="  إنزال الملفات المختارة ";
$lang['media_upload_uploadfile']="تحميل الملف";
$lang['media_upload_title']="تحميل الملفات";
$lang['media_upload_success']=" تم تحميل الملف بنجاح ";
$lang['media_upload_error']="فشل في تحميل الملف";
$lang['media_upload_listfile']="رابط الملف";
$lang['media_upload_listimg']="رابط الصورة المصغرة";
$lang['media_formadd']="إدراج الملف ";
// Category Manager
$lang['cat_title']="إدارة ألاقسام ";
$lang['cat_new']="قسم جديد";
$lang['cat_name1']="أسم القسم";
$lang['cat_name2']="أسم القسم -اللغة الاجنبية";
$lang['cat_parent']="الفرع";
$lang['cat_img']="صورة القسم";
$lang['cat_save']="حفظ البيانات";
$lang['cat_update']="تعديل البيانات";
$lang['cat_ID']="رقم القسم";
$lang['cat_edit']="تعديل القسم";
$lang['cat_delete']="حذف الاقسام المختارة";
$lang['cat_addok']="تم إضافة بيانات القسم بنجاح";
$lang['cat_adderror']="  حدث خطأ في تسجيل القسم او القسم مسجل من قبل";
$lang['cat_archive']=" أرشيف ألاقسام";
$lang['cat_nopic']="لا يوجد صورة";
$lang['cat_back']=" عودة ";
$lang['cat_noName']=" أسم القسم مفقود ";
$lang['cat_module']='ربط مع موديول';
 
$lang['mem_title']="إدارة الاعضاء والمشرفين";
$lang['mem_newuser']="عضوية جديدة";
$lang['mem_edituser']="تعديل البيانات";
$lang['mem_options']="خيارات الاعضاء";
$lang['mem_listuser']="قائمة الاعضاء المسجلين";
$lang['mem_name']="ألاسم";
$lang['mem_email']="البريد الالكتروني";
$lang['mem_gender']="الجنس";
$lang['mem_pic']="الصور الرمزية";
$lang['mem_role']="الصلاحيات";
$lang['mem_datereg']="تاريخ التسجيل";
$lang['mem_active']="تفعيل الحساب";
$lang['mem_on']=" الحساب مفعل";
$lang['mem_off']="الحساب غير مفعل";
$lang['mem_status_acount']="حالة الحساب";
$lang['mem_viewinfo']="عرض البيانات";
$lang['mem_btn_delete']="حذف";
$lang['mem_btn_dactive']=" إلغاء تفعيل الحساب";
$lang['mem_country']="الدولة";
$lang['mem_username']="أسم المستخدم";
$lang['mem_password']="كلمة المرور";
$lang['mem_gender_male']="ذكر";
$lang['mem_gender_female']="أنثي";
$lang['mem_role_user']="مستخدم";
$lang['mem_role_admin']="مدير";

$lang['mem_missing_name']='الاسم مفقود';
$lang['mem_missing_email']='البريد الالكتروني مفقود او غير صالح';
$lang['mem_missing_username']='اسم المستخدم مفقود';
$lang['mem_missing_password']='كلمة المرور مفقودة';
$lang['mem_msg_add']="تم إضافة بيانات العضو بنجاح";
$lang['mem_msg_error']="فشل في إضافة البيانات  او البريد   مسجل من قبل";

$lang['mem_option_activeuser']='تفعيل إشتراك الاعضاء من خلال';
$lang['mem_option_webcam']='استخدام خدمة الصور الرمزية (WebCam)';
$lang['mem_option_avatar']='استخدام خدمة الصور الرمزية (Avatar)';
$lang['mem_option_notifications']='   تفعيل ألاشعارات عند تسجيل الاعضاء  ';
$lang['mem_option_activeby_auto']='تفعيل تلقائي';
$lang['mem_option_activeby_admin']='من خلال مدير الموقع';
$lang['mem_option_activeby_email']='من خلال رابط تفعيل';
$lang['mem_login']='دخول';
$lang['mem_login_errormsg']=" خطأ في تسجيل الدخول ";
$lang['mem_login_title']=" تسجيل دخول";
$lang['mem_option_reg']=" إمكانية التسجيل في الموقع";

$lang['chart_vistors']="إحصائيات الزوار";
$lang['chart_size']=" إحصائيات المساحة المتوفرة "; 
$lang['chart_memory']=" حجم الذاكرة المستخدمة"; 
$lang['chart_info']=" معلومات الموقع ";
$lang['chart_members']=" إحصائيات المشتركين والزوار ";  
$lang['chart_ossystem']=" نظام التشغيل";
$lang['chart_phpversion']="PHP إصدار ";
$lang['chart_mysqlversion']="MySql إصدار ";
$lang['chart_serverversion']="الخادم";
$lang['chart_sizedb']="حجم قاعدة البيانات";
//$lang['chart_extentions']="";
$lang['chart_foldermedia']="حجم مجلد الملفات المحملة";
$lang['chart_vistornow']="الزوار المتواجدون الان";
$lang['chart_membernow']="الاعضاء المتواجدون الان";
$lang['chart_membermanagernum']="مديرين الموقع";
$lang['chart_membernum']="إجمالي عدد الاعضاء المسجلين";
$lang['chart_memberactive']="عدد الاعضاء في إنتظار التفعيل";
$lang['chart_usedsize']='  المستخدمة';
$lang['chart_allsize']='  المتوافرة';
$lang['plugin_article']="المقالات -ألاخبار";
$lang['plugin_media']="الفيدوهات  ";
$lang['plugin_poll']="ألاستفتاءات";
$lang['plugin_advert']="ألاعلانات";



?>